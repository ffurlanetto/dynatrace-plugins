import time
import math
import traceback
import sys
import logging
import datetime
import os

from ruxit.api.base_plugin import RemoteBasePlugin

if sys.platform == "win32":
    # This ugly code is necessary because of pywin32 and how the plugin engine sets paths
    # We must have these in our path before importing pythoncom
    sys.frozen = True
    sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "win32")))
    sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "win32", "lib")))
    sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "Pythonwin")))
    sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "pywin32_system32")))


logger = logging.getLogger(__name__)

class WMI_Class(RemoteBasePlugin):
    NAME = 0
    PF_PER_SEC = 1
    THREAD_COUNT = 2
    IO_READ_PER_SEC = 3
    IO_WRITE_PER_SEC = 4
    MEMORY_USAGE = 5
    TIMESTAMP_SYS = 6
    PERCENT_PROCESSOR_TIME = 7
    AVG_DISK_READ_QUEUE_LENGTH = 8
    AVG_DISK_WRITE_QUEUE_LENGTH = 9
    AVG_DISK_SEC_PER_READ = 10
    AVG_DISK_SEC_PER_READ_BASE = 11
    AVG_DISK_SEC_PER_WRITE = 12
    AVG_DISK_SEC_PER_WRITE_BASE = 13
    DISK_READ_BYTES_PER_SEC = 14
    DISK_WRITE_BYTES_PER_SEC = 15
    TIMESTAMP_OBJECT = 16
    TIMESTAMP_PERFTIME = 17
    FREQUENCY_OBJECT = 18
    CURRENT_BANDWIDTH = 19
    BYTES_RECEIVED_PER_SEC = 20
    BYTES_SENT_PER_SEC = 21
    PACKETS_OUTBOUND_DISCARDED = 22
    PACKETS_OUTBOUND_ERRORS = 23
    PACKETS_INBOUND_DISCARDED = 24
    PACKETS_INBOUND_ERRORS = 25
    FREQUENCY_SYS = 26
    AVAILABILITY = 27
    CPU = 28
    PROCESS = 29
    DISK = 30
    NETWORK = 31
    IPS = 32
    MEMORY = 33
    PROPERTIES = 34
    TOTAL_MEMORY = 35
    FREE_MEMORY = 36
    CURRENT_CLOCK_SPEED = 37
    MAX_CLOCK_SPEED = 38
    PROCESSOR_NAME = 39
    NUMBER_OF_CORES = 40
    NUMBER_OF_LOGICAL_PROCESSORS = 41
    DOMAIN = 42
    MANUFACTURER = 43
    MODEL = 44
    ACHITECTURE = 45
    WIN_NAME = 46
    BUILD_NUMBER = 47
    UPTIME = 48
    OUTPUT_QUEUE_LENGTH = 49
    FREQUENCY_PERFTIME = 50
    PERCENT_FREE_SPACE = 51
    PERCENT_FREE_SPACE_BASE = 52
    FREE_MEGABYTES = 53
    READ_TIME = 54
    LOCAL_TIME = 55
    EVENTS = 56
    MESSAGE = 57
    LOG_FILE = 58
    SOURCE_NAME = 59

    BOOT_TIMESTAMP = "%Y%m%d%H%M%S"
    
    QUERY_PROCESSOR = "SELECT * FROM Win32_Processor"
    QUERY_COMPUTERSYSTEM = "SELECT TotalPhysicalMemory, Domain, Manufacturer, Model, Name FROM Win32_ComputerSystem"
    QUERY_OPERATINGSYSTEM = "SELECT * FROM Win32_OperatingSystem"
    QUERY_NETWORKCONFIG = "SELECT IPAddress FROM Win32_NetworkAdapterConfiguration WHERE IPEnabled = 'True'"
    QUERY_DISK = "SELECT Name, AvgDiskReadQueueLength, AvgDiskWriteQueueLength, AvgDiskSecPerRead, AvgDiskSecPerRead_Base, AvgDiskSecPerWrite, AvgDiskSecPerWrite_Base, DiskReadBytesPerSec, DiskWriteBytesPerSec, FreeMegabytes, PercentFreeSpace, PercentFreeSpace_Base, Timestamp_Object, Timestamp_PerfTime, TimeStamp_Sys100NS, Frequency_PerfTime FROM Win32_PerfRawData_PerfDisk_LogicalDisk WHERE Name LIKE '%:%'"
    QUERY_PROCESS = "SELECT * FROM Win32_PerfRawData_PerfProc_Process WHERE ({:s}) AND IDProcess > 0"
    QUERY_EVENTS = "SELECT * from Win32_NTLogEvent WHERE EventType = 1 AND TimeWritten >= '{:s}' AND ({:s})"
    QUERY_PERF_PROCESSOR = "SELECT PercentProcessorTime, TimeStamp_Sys100NS FROM Win32_PerfRawData_PerfOS_Processor where Name='_Total'"
    QUERY_PERF_NETWORK = "SELECT Name, CurrentBandwidth, TimeStamp_Sys100NS, Frequency_Sys100NS, BytesReceivedPerSec, BytesSentPerSec, PacketsOutboundDiscarded, PacketsOutboundErrors, PacketsReceivedDiscarded, PacketsReceivedErrors, OutputQueueLength FROM Win32_PerfRawData_Tcpip_NetworkInterface WHERE NOT Name LIKE 'isatap.%'"
    
    previousPoll = {}

    # Used for not spamming events
    previousEvents = []
    raisedEvents = []
    
    # Used for limiting events
    MAX_EVENTS = 100
    events = 0
    
    # Used to always have debug logging enabled the first run
    firstRun = True
    
    def query(self, **kwargs):

        logger.info(f'sys.path = {sys.path}, curr_dir={os.path.abspath(os.path.dirname(__file__))}')
        for f in os.listdir(os.path.abspath(os.path.dirname(__file__))):
            logger.info(f"Found file: {f}")

        import pythoncom
        pythoncom.CoInitialize()
        import wmi

        self.events = 0
        self.raisedEvents = []
        config = kwargs["config"]
        hostName = config["host_name"]
        group = config["group"]
        username = config["auth_user"]
        password = config["auth_password"]
        processesToMonitor = config["processes"].strip()
        logFilesToMonitor = config["log_files"].strip()
        
        debugLogging = config["debug"]
        if debugLogging or self.firstRun:
            logger.setLevel(logging.DEBUG)
            self.firstRun = False
        else:
            logger.setLevel(logging.WARNING)
        
        if hostName in self.previousPoll:
            logger.info(hostName + " - Found previous poll")
            if self.PROPERTIES in self.previousPoll[hostName] and self.LOCAL_TIME in self.previousPoll[hostName][self.PROPERTIES]:
                metrics = self.pollWMI(wmi, hostName, username, password, processesToMonitor, logFilesToMonitor, self.previousPoll[hostName][self.PROPERTIES][self.LOCAL_TIME])
            else:
                metrics = self.pollWMI(wmi, hostName, username, password, processesToMonitor, logFilesToMonitor, None)
            self.sendMetrics(hostName, group, self.previousPoll[hostName], metrics, kwargs["json_config"]["version"])
            if self.CPU in metrics and self.PERCENT_PROCESSOR_TIME in metrics[self.CPU]:
                self.previousPoll[hostName] = metrics
        else:
            logger.info(hostName + " - Didn't find previous poll")
            metrics = self.pollWMI(wmi, hostName, username, password, processesToMonitor, logFilesToMonitor, None)
            if self.CPU in metrics and self.PERCENT_PROCESSOR_TIME in metrics[self.CPU]:
                self.previousPoll[hostName] = metrics
                self.previousEvents = self.raisedEvents
                time.sleep(10)
                if self.PROPERTIES in self.previousPoll[hostName] and self.LOCAL_TIME in self.previousPoll[hostName][self.PROPERTIES]:
                    metrics = self.pollWMI(wmi, hostName, username, password, processesToMonitor, logFilesToMonitor, self.previousPoll[hostName][self.PROPERTIES][self.LOCAL_TIME])
                else:
                    metrics = self.pollWMI(wmi, hostName, username, password, processesToMonitor, logFilesToMonitor, None)
            if hostName in self.previousPoll:
                self.sendMetrics(hostName, group, self.previousPoll[hostName], metrics, kwargs["json_config"]["version"])
            else:
                self.sendMetrics(hostName, group, None, metrics, kwargs["json_config"]["version"])
            if self.CPU in metrics and self.PERCENT_PROCESSOR_TIME in metrics[self.CPU]:
                self.previousPoll[hostName] = metrics
        self.previousEvents = self.raisedEvents
        pythoncom.CoUninitialize()
    
    def pollWMI(self, wmi, hostName, username, password, processesToMonitor, logFilesToMonitor, lastLocalTime):
        logger.info(hostName + " - Polling WMI")
        availability = 0
        properties = {}
        memory = {}
        ips = []
        logicalDisks = {}
        processes = {}
        cpu = {}
        networkInterfaces = {}
        events = []
        try:
            if username != "":
                if "\\" not in username:
                    username = hostName + "\\" + username
                c = wmi.WMI (computer=hostName, user=username, password=password)
            else:
                c = wmi.WMI (computer=hostName)
            availability = 100
        except wmi.x_wmi as e:
            if not hasattr(e, "com_error") or not hasattr(e.com_error, "hresult"):
                logger.exception(hostName + " - Unknown exception")
            else:
                logger.exception(hostName + " - COM exception")
        except Exception as e:
            logger.exception(hostName + " - Unknown exception")
            
        if availability == 100:
            if lastLocalTime is not None and logFilesToMonitor != "":
                # Build log file WHERE clause
                logArray = logFilesToMonitor.split(",")
                logTrimmed = []
                for log in logArray:
                    logTrimmed.append(log.strip())
                whereClause = "' OR Logfile = '".join(logTrimmed)
                
                # Get process information
                print(self.QUERY_EVENTS.format(lastLocalTime, "Logfile = '" + whereClause + "'"))
                logEvents = c.ExecQuery(self.QUERY_EVENTS.format(lastLocalTime, "Logfile = '" + whereClause + "'"))
                for logEvent in logEvents:
                    events.append({self.MESSAGE: logEvent.Message, self.LOG_FILE: logEvent.Logfile, self.SOURCE_NAME: logEvent.SourceName})

            # Get processor properties
            processorInfos = c.ExecQuery(self.QUERY_PROCESSOR)
            for processorInfo in processorInfos:
                properties[self.CURRENT_CLOCK_SPEED] = processorInfo.CurrentClockSpeed
                properties[self.MAX_CLOCK_SPEED] = processorInfo.MaxClockSpeed
                properties[self.PROCESSOR_NAME] = processorInfo.Name
                if hasattr(processorInfo, "NumberOfCores"):
                    properties[self.NUMBER_OF_CORES] = processorInfo.NumberOfCores
                if hasattr(processorInfo, "NumberOfLogicalProcessors"):
                    properties[self.NUMBER_OF_LOGICAL_PROCESSORS] = processorInfo.NumberOfLogicalProcessors
                
            # Get server memory usage and properties
            computerSystems = c.ExecQuery(self.QUERY_COMPUTERSYSTEM)
            for computerSystem in computerSystems:
                memory[self.TOTAL_MEMORY] = int(computerSystem.TotalPhysicalMemory)/1024
                properties[self.DOMAIN] = computerSystem.Domain
                properties[self.MANUFACTURER] = computerSystem.Manufacturer
                properties[self.MODEL] = computerSystem.Model
                properties[self.NAME] = computerSystem.Name
                
            # Get OS information
            operatingSystem = c.ExecQuery(self.QUERY_OPERATINGSYSTEM)
            for os in operatingSystem:
                bootTime = datetime.datetime.strptime(os.LastBootUpTime[:14], self.BOOT_TIMESTAMP)
                localTime = datetime.datetime.strptime(os.LocalDateTime[:14], self.BOOT_TIMESTAMP)
                properties[self.LOCAL_TIME] = os.LocalDateTime
                memory[self.FREE_MEMORY] = int(os.FreePhysicalMemory)
                if hasattr(os, "OSArchitecture"):
                    properties[self.ACHITECTURE] = os.OSArchitecture
                properties[self.WIN_NAME] = os.Caption
                properties[self.BUILD_NUMBER] = os.BuildNumber
                properties[self.UPTIME] = self.display_time((localTime-bootTime).total_seconds())
                
            # Get IPs
            networkIPs = c.ExecQuery(self.QUERY_NETWORKCONFIG)
            for networkIP in networkIPs:
                for ip in networkIP.IPAddress:
                    if "." in ip:
                        ips.append(ip)
                
            disks = c.ExecQuery(self.QUERY_DISK)
            for disk in disks:
                name = disk.Name
                logicalDisks[name] = {}
                logicalDisk = logicalDisks[name]
                logicalDisk[self.AVG_DISK_READ_QUEUE_LENGTH] = int(disk.AvgDiskReadQueueLength)
                logicalDisk[self.PERCENT_FREE_SPACE] = disk.PercentFreeSpace
                logicalDisk[self.PERCENT_FREE_SPACE_BASE] = disk.PercentFreeSpace_Base
                logicalDisk[self.FREE_MEGABYTES] = disk.FreeMegabytes
                logicalDisk[self.AVG_DISK_WRITE_QUEUE_LENGTH] = int(disk.AvgDiskWriteQueueLength)
                logicalDisk[self.AVG_DISK_SEC_PER_READ] = disk.AvgDiskSecPerRead
                logicalDisk[self.AVG_DISK_SEC_PER_READ_BASE] = disk.AvgDiskSecPerRead_Base
                logicalDisk[self.AVG_DISK_SEC_PER_WRITE] = disk.AvgDiskSecPerWrite
                logicalDisk[self.AVG_DISK_SEC_PER_WRITE_BASE] = disk.AvgDiskSecPerWrite_Base
                logicalDisk[self.DISK_READ_BYTES_PER_SEC] = int(disk.DiskReadBytesPerSec)
                logicalDisk[self.DISK_WRITE_BYTES_PER_SEC] = int(disk.DiskWriteBytesPerSec)
                logicalDisk[self.TIMESTAMP_OBJECT] = int(disk.Timestamp_Object)
                logicalDisk[self.TIMESTAMP_PERFTIME] = int(disk.Timestamp_PerfTime)
                logicalDisk[self.READ_TIME] = int(disk.TimeStamp_Sys100NS)
                logicalDisk[self.FREQUENCY_PERFTIME] = int(disk.Frequency_PerfTime)

            # Get server CPU utilization
            cpuInfos = c.ExecQuery(self.QUERY_PERF_PROCESSOR)
            for cpuinfo in cpuInfos:
                cpu[self.PERCENT_PROCESSOR_TIME] = int(cpuinfo.PercentProcessorTime)
                cpu[self.TIMESTAMP_SYS] = int(cpuinfo.TimeStamp_Sys100NS)
                
            interfaces = c.ExecQuery(self.QUERY_PERF_NETWORK)
            for interface in interfaces:
                name = interface.Name
                networkInterfaces[name] = {}
                networkInterface = networkInterfaces[name]
                networkInterface[self.CURRENT_BANDWIDTH] = interface.CurrentBandwidth
                networkInterface[self.BYTES_RECEIVED_PER_SEC] = int(interface.BytesReceivedPerSec)
                networkInterface[self.BYTES_SENT_PER_SEC] = int(interface.BytesSentPerSec)
                networkInterface[self.PACKETS_OUTBOUND_DISCARDED] = int(interface.PacketsOutboundDiscarded)
                networkInterface[self.PACKETS_OUTBOUND_ERRORS] = int(interface.PacketsOutboundErrors)
                networkInterface[self.PACKETS_INBOUND_DISCARDED] = int(interface.PacketsReceivedDiscarded)
                networkInterface[self.PACKETS_INBOUND_ERRORS] = int(interface.PacketsReceivedErrors)
                networkInterface[self.OUTPUT_QUEUE_LENGTH] = int(interface.OutputQueueLength)
                networkInterface[self.FREQUENCY_SYS] = int(interface.Frequency_Sys100NS)
                networkInterface[self.TIMESTAMP_SYS] = int(interface.TimeStamp_Sys100NS)
            
            if processesToMonitor != "":
                # Build process WHERE clause
                processArray = processesToMonitor.split(",")
                processTrimmed = []
                for process in processArray:
                    processTrimmed.append(process.strip())
                whereClause = "' OR Name = '".join(processTrimmed)
                
                # Get process information
                perfDataProcesses = c.ExecQuery(self.QUERY_PROCESS.format("Name = '" + whereClause + "'"))
                for perfDataProcess in perfDataProcesses:
                    processes[perfDataProcess.Name] = {}
                    process = processes[perfDataProcess.Name]
                    process[self.PF_PER_SEC] = perfDataProcess.PageFaultsPerSec
                    process[self.THREAD_COUNT] = perfDataProcess.ThreadCount
                    process[self.IO_READ_PER_SEC] = int(perfDataProcess.IOReadBytesPerSec)
                    process[self.IO_WRITE_PER_SEC] = int(perfDataProcess.IOWriteBytesPerSec)
                    if hasattr(perfDataProcess, "WorkingSetPrivate"):
                        process[self.MEMORY_USAGE] = int(perfDataProcess.WorkingSetPrivate)
                    elif hasattr(perfDataProcess, "WorkingSet"):
                        process[self.MEMORY_USAGE] = int(perfDataProcess.WorkingSet)
                    process[self.PERCENT_PROCESSOR_TIME] = int(perfDataProcess.PercentProcessorTime)
                    process[self.READ_TIME] = int(perfDataProcess.Timestamp_Sys100NS)
                    process[self.FREQUENCY_OBJECT] = int(perfDataProcess.Frequency_Object)
                    process[self.TIMESTAMP_OBJECT] = int(perfDataProcess.Timestamp_Object)
                    process[self.AVAILABILITY] = 100
                    
                # Get missing processes
                for process in processTrimmed:
                    if process not in processes:
                        processes[process] = {}
                        processes[process][self.AVAILABILITY] = 0

        logger.info(hostName + " - Polled WMI")

        return {self.EVENTS: events, self.AVAILABILITY: availability, self.NETWORK: networkInterfaces, self.PROCESS: processes, self.CPU: cpu, self.DISK: logicalDisks, self.IPS: ips, self.MEMORY: memory, self.PROPERTIES: properties}
    
    def sendMetrics(self, hostName, group, prevMetrics, metrics, pluginVersion):
        logger.info(hostName + " - Send metrics")
        g1 = self.topology_builder.create_group("WMI - " + group, "WMI - " + group)
        e1 = g1.create_element("WMI - " + group + " - " + hostName, "WMI - " + group + " - " + hostName)
        e1.report_property("Plugin version", pluginVersion)
        if metrics[self.AVAILABILITY] == 100 and prevMetrics != None:
            logger.info(hostName + " - Found metrics")
            for event in metrics[self.EVENTS]:
                self.report_custom_info_event(e1, event[self.MESSAGE], "Error in log '" + event[self.LOG_FILE] + "'. Source: '" + event[self.SOURCE_NAME] + "'")

            for interface in metrics[self.NETWORK]:
                if interface in prevMetrics[self.NETWORK]:
                    data = metrics[self.NETWORK][interface]
                    prevData = prevMetrics[self.NETWORK][interface]
                    e1.absolute(key = "NetworkBandwidth", value = round(int(data[self.CURRENT_BANDWIDTH])), dimensions = {"Interface": interface})
                    e1.absolute(key = "NetworkSent", value = round((data[self.BYTES_SENT_PER_SEC] - prevData[self.BYTES_SENT_PER_SEC]) / ((data[self.TIMESTAMP_SYS] - prevData[self.TIMESTAMP_SYS]) / data[self.FREQUENCY_SYS])), dimensions = {"Interface": interface})
                    e1.absolute(key = "NetworkReceived", value = round((data[self.BYTES_RECEIVED_PER_SEC] - prevData[self.BYTES_RECEIVED_PER_SEC]) / ((data[self.TIMESTAMP_SYS] - prevData[self.TIMESTAMP_SYS]) / data[self.FREQUENCY_SYS])), dimensions = {"Interface": interface})
                    e1.absolute(key = "NetworkSentDiscarded", value = round(data[self.PACKETS_OUTBOUND_DISCARDED] - prevData[self.PACKETS_OUTBOUND_DISCARDED]), dimensions = {"Interface": interface})
                    e1.absolute(key = "NetworkSentErrors", value = round(data[self.PACKETS_OUTBOUND_ERRORS] - prevData[self.PACKETS_OUTBOUND_ERRORS]), dimensions = {"Interface": interface})
                    e1.absolute(key = "NetworkReceivedDiscarded", value = round(data[self.PACKETS_INBOUND_DISCARDED] - prevData[self.PACKETS_INBOUND_DISCARDED]), dimensions = {"Interface": interface})
                    e1.absolute(key = "NetworkReceivedErrors", value = round(data[self.PACKETS_INBOUND_ERRORS] - prevData[self.PACKETS_INBOUND_ERRORS]), dimensions = {"Interface": interface})
                    e1.absolute(key = "NetworkOutputQueueLength", value = round(int(data[self.OUTPUT_QUEUE_LENGTH])), dimensions = {"Interface": interface})
            
            for disk in metrics[self.DISK]:
                if disk in prevMetrics[self.DISK]:
                    data = metrics[self.DISK][disk]
                    prevData = prevMetrics[self.DISK][disk]
                    avgDiskSecPerRead = 0
                    avgDiskSecPerWrite = 0
                    if data[self.AVG_DISK_SEC_PER_READ_BASE] != prevData[self.AVG_DISK_SEC_PER_READ_BASE] and data[self.FREQUENCY_PERFTIME] != 0:
                        avgDiskSecPerRead = (data[self.AVG_DISK_SEC_PER_READ] - prevData[self.AVG_DISK_SEC_PER_READ]) / data[self.FREQUENCY_PERFTIME] / (data[self.AVG_DISK_SEC_PER_READ_BASE] - prevData[self.AVG_DISK_SEC_PER_READ_BASE])
                    if data[self.AVG_DISK_SEC_PER_WRITE_BASE] != prevData[self.AVG_DISK_SEC_PER_WRITE_BASE] and data[self.FREQUENCY_PERFTIME] != 0:
                        avgDiskSecPerWrite = (data[self.AVG_DISK_SEC_PER_WRITE] - prevData[self.AVG_DISK_SEC_PER_WRITE]) / data[self.FREQUENCY_PERFTIME] / (data[self.AVG_DISK_SEC_PER_WRITE_BASE] - prevData[self.AVG_DISK_SEC_PER_WRITE_BASE])
                    e1.absolute(key = "DiskWriteLatency", value = round(avgDiskSecPerWrite), dimensions = {"LogicalDisk": disk})
                    e1.absolute(key = "DiskReadLatency", value = round(avgDiskSecPerRead), dimensions = {"LogicalDisk": disk})
                    e1.absolute(key = "DiskPercentFreeSpace", value = round(100 * data[self.PERCENT_FREE_SPACE] / data[self.PERCENT_FREE_SPACE_BASE]), dimensions = {"LogicalDisk": disk})
                    e1.absolute(key = "DiskFree", value = round(data[self.FREE_MEGABYTES]), dimensions = {"LogicalDisk": disk})
                    e1.absolute(key = "DiskWriteQueueLength", value = round((data[self.AVG_DISK_WRITE_QUEUE_LENGTH] - prevData[self.AVG_DISK_WRITE_QUEUE_LENGTH]) / (data[self.READ_TIME] - prevData[self.READ_TIME])), dimensions = {"LogicalDisk": disk})
                    e1.absolute(key = "DiskReadQueueLength", value = round((data[self.AVG_DISK_READ_QUEUE_LENGTH] - prevData[self.AVG_DISK_READ_QUEUE_LENGTH]) / (data[self.READ_TIME] - prevData[self.READ_TIME])), dimensions = {"LogicalDisk": disk})
                    e1.absolute(key = "DiskWrite", value = round(10000000*(data[self.DISK_WRITE_BYTES_PER_SEC] - prevData[self.DISK_WRITE_BYTES_PER_SEC]) / (data[self.READ_TIME] - prevData[self.READ_TIME])), dimensions = {"LogicalDisk": disk})
                    e1.absolute(key = "DiskRead", value = round(10000000*(data[self.DISK_READ_BYTES_PER_SEC] - prevData[self.DISK_READ_BYTES_PER_SEC]) / (data[self.READ_TIME] - prevData[self.READ_TIME])), dimensions = {"LogicalDisk": disk})
            
            # Iterate over the list of all processes
            for process in metrics[self.PROCESS]:
                if process in prevMetrics[self.PROCESS]:
                    data = metrics[self.PROCESS][process]
                    prevData = prevMetrics[self.PROCESS][process]
                    if self.AVAILABILITY in data and data[self.AVAILABILITY] is not None and process is not None:
                        availability = data[self.AVAILABILITY]
                        e1.absolute(key = "ProcessAvailability", value = availability, dimensions = {"Process": process})
                        if availability == 0:
                            self.report_custom_info_event(e1, "Process not running: '" + process + "'", "Process not running: '" + process + "'")
                        else:
                            if self.PERCENT_PROCESSOR_TIME in data and self.PERCENT_PROCESSOR_TIME in prevData:
                                e1.absolute(key = "ProcessCPULoad", value = round((data[self.PERCENT_PROCESSOR_TIME] - prevData[self.PERCENT_PROCESSOR_TIME]) / (data[self.READ_TIME] - prevData[self.READ_TIME]) * 100), dimensions = {"Process": process})
                                if self.MEMORY_USAGE in data:
                                    e1.absolute(key = "ProcessMemoryUsage", value = data[self.MEMORY_USAGE], dimensions = {"Process": process})
                                e1.absolute(key = "ProcessPageFaults", value = (data[self.PF_PER_SEC] - prevData[self.PF_PER_SEC]) / ((data[self.TIMESTAMP_OBJECT] - prevData[self.TIMESTAMP_OBJECT]) / data[self.FREQUENCY_OBJECT]), dimensions = {"Process": process})
                                e1.absolute(key = "ProcessThreadCount", value = data[self.THREAD_COUNT], dimensions = {"Process": process})
                                e1.absolute(key = "ProcessIORead", value = (data[self.IO_READ_PER_SEC] - prevData[self.IO_READ_PER_SEC]) / ((data[self.TIMESTAMP_OBJECT] - prevData[self.TIMESTAMP_OBJECT]) / data[self.FREQUENCY_OBJECT]), dimensions = {"Process": process})
                                e1.absolute(key = "ProcessIOWrite", value = (data[self.IO_WRITE_PER_SEC] - prevData[self.IO_WRITE_PER_SEC]) / ((data[self.TIMESTAMP_OBJECT] - prevData[self.TIMESTAMP_OBJECT]) / data[self.FREQUENCY_OBJECT]), dimensions = {"Process": process})
            
            e1.absolute(key = "CPULoad", value = round((1 - (metrics[self.CPU][self.PERCENT_PROCESSOR_TIME] - prevMetrics[self.CPU][self.PERCENT_PROCESSOR_TIME]) / (metrics[self.CPU][self.TIMESTAMP_SYS] - prevMetrics[self.CPU][self.TIMESTAMP_SYS])) * 100))
            e1.absolute(key = "MemoryUtilization", value = round((1 - metrics[self.MEMORY][self.FREE_MEMORY] / metrics[self.MEMORY][self.TOTAL_MEMORY]) * 100))
            
            e1.report_property("Name", metrics[self.PROPERTIES][self.NAME])
            e1.report_property("Domain", metrics[self.PROPERTIES][self.DOMAIN])
            try:
                for ip in metrics[self.IPS]:
                    e1.add_endpoint(ip)
                    logger.info("Adding endpoint " + ip)
            except TypeError as e:
                e1.report_property("IP(s)", ", ".join(metrics[self.IPS]))
            e1.report_property("Uptime", metrics[self.PROPERTIES][self.UPTIME])
            e1.report_property("Windows version", metrics[self.PROPERTIES][self.WIN_NAME])
            e1.report_property("Build number", metrics[self.PROPERTIES][self.BUILD_NUMBER])
            if self.ACHITECTURE in metrics[self.PROPERTIES]:
                e1.report_property("Architecture", metrics[self.PROPERTIES][self.ACHITECTURE])
            e1.report_property("Manufacturer", metrics[self.PROPERTIES][self.MANUFACTURER])
            e1.report_property("Model", metrics[self.PROPERTIES][self.MODEL])
            e1.report_property("Processor", metrics[self.PROPERTIES][self.PROCESSOR_NAME])
            if self.NUMBER_OF_CORES in metrics[self.PROPERTIES]:
                e1.report_property("Number of cores", str(metrics[self.PROPERTIES][self.NUMBER_OF_CORES]))
            if self.NUMBER_OF_LOGICAL_PROCESSORS in metrics[self.PROPERTIES]:
                e1.report_property("Number of logical processors", str(metrics[self.PROPERTIES][self.NUMBER_OF_LOGICAL_PROCESSORS]))
            e1.report_property("Current clock speed", str(metrics[self.PROPERTIES][self.CURRENT_CLOCK_SPEED]) + "Mhz")
            e1.report_property("Max clock speed", str(metrics[self.PROPERTIES][self.MAX_CLOCK_SPEED]) + "Mhz")
        else:
            self.report_custom_info_event(e1, "Cannot connect to server", "Cannot connect to server")
        e1.absolute(key = "Availability", value = metrics[self.AVAILABILITY])
        logger.info(hostName + " - Sent metrics")
        
    def display_time(self, seconds, granularity=2):
        intervals = (
            ('weeks', 604800),  # 60 * 60 * 24 * 7
            ('days', 86400),    # 60 * 60 * 24
            ('hours', 3600),    # 60 * 60
            ('minutes', 60),
            ('seconds', 1))
        result = []
        for name, count in intervals:
            value = math.floor(seconds // count)
            if value:
                seconds -= value * count
                if value == 1:
                    name = name.rstrip('s')
                result.append("{} {}".format(value, name))
        return ', '.join(result[:granularity])
        
    def report_custom_info_event(self, e1, message, title):
        if self.events < self.MAX_EVENTS and title is not None and message is not None:
            if title + message not in self.previousEvents:
                self.events += 1
                e1.report_custom_info_event(message, title)
            self.raisedEvents.append(title + message)