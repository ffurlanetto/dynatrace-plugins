import json
import logging
from ruxit.api.base_plugin import RemoteBasePlugin
from ruxit.api.exceptions import AuthException, ConfigException
import socket
import time
import re
from datetime import datetime, timedelta
import requests
from requests.auth import HTTPBasicAuth

logger = logging.getLogger(__name__)
MAX_RESULTS = 100
MAX_EVENTS = 99

class CustomApigeePluginRemote(RemoteBasePlugin):
    proxy_metrics = { 'tps': {'metric_type': 'absolute', 'metric_name': 'proxy_tps', 'split_name': 'Proxy'},
                'sum(message_count)': {'metric_type': 'absolute', 'metric_name': 'proxy_message_count', 'split_name': 'Proxy'},
                'sum(is_error)': {'metric_type': 'absolute', 'metric_name': 'proxy_errors', 'split_name': 'Proxy'},
                'sum(cache_hit)': {'metric_type': 'absolute', 'metric_name': 'proxy_cache_hit', 'split_name': 'Proxy'},
                'sum(target_error)': {'metric_type': 'absolute', 'metric_name': 'proxy_target_errors', 'split_name': 'Proxy'},
                'avg(total_response_time)': {'metric_type': 'absolute', 'metric_name': 'proxy_total_response_time', 'prefix': 'global-avg-', 'split_name': 'Proxy'},
                'avg(target_response_time)': {'metric_type': 'absolute', 'metric_name': 'proxy_target_response_time', 'prefix': 'global-avg-', 'split_name': 'Proxy'},
                'avg(request_size)': {'metric_type': 'absolute', 'metric_name': 'proxy_request_size', 'prefix': 'global-avg-', 'split_name': 'Proxy'},
                'avg(response_size)': {'metric_type': 'absolute', 'metric_name': 'proxy_response_size', 'prefix': 'global-avg-', 'split_name': 'Proxy'},
                'avg(request_processing_latency)': {'metric_type': 'absolute', 'metric_name': 'proxy_request_processing_latency', 'prefix': 'global-avg-', 'split_name': 'Proxy'},
                'avg(response_processing_latency)': {'metric_type': 'absolute', 'metric_name': 'proxy_response_processing_latency', 'prefix': 'global-avg-', 'split_name': 'Proxy'}    
    }
    
    target_metrics = { 'tps': {'metric_type': 'absolute', 'metric_name': 'target_tps', 'split_name': 'Target'},
                'sum(message_count)': {'metric_type': 'absolute', 'metric_name': 'target_message_count', 'split_name': 'Target'},
                'sum(target_error)': {'metric_type': 'absolute', 'metric_name': 'target_errors', 'split_name': 'Target'},
                'avg(target_response_time)': {'metric_type': 'absolute', 'metric_name': 'target_response_time', 'prefix': 'global-avg-', 'split_name': 'Target'},
                'avg(request_size)': {'metric_type': 'absolute', 'metric_name': 'target_request_size', 'prefix': 'global-avg-', 'split_name': 'Target'},
                'avg(response_size)': {'metric_type': 'absolute', 'metric_name': 'target_response_size', 'prefix': 'global-avg-', 'split_name': 'Target'},
                'avg(request_processing_latency)': {'metric_type': 'absolute', 'metric_name': 'target_request_processing_latency', 'prefix': 'global-avg-', 'split_name': 'Target'},
                'avg(response_processing_latency)': {'metric_type': 'absolute', 'metric_name': 'target_response_processing_latency', 'prefix': 'global-avg-', 'split_name': 'Target'}    
    }
    
    base_url = 'https://api.enterprise.apigee.com'
    oauth_url = 'https://login.apigee.com/oauth/token'
    
    auth_method = "Basic"
    saml_zone = None
    tokens = {}
    
    def query(self, **kwargs):
        logger.info(f'Polling to Apigee API')
        config = kwargs['config']
        
        if config['debug']:
            logging.basicConfig(level=logging.DEBUG)
            logger.setLevel(logging.DEBUG)
        else:
            logger.setLevel(logging.INFO)
        
        self.previousEvents = []
        self.events = 0
    
        # Config GUI vars
        self.org = config['org'].strip()
        self.env = config['env'].strip()
        self.auth_method = config['auth_method']
        self.saml_zone = config['saml_zone'].strip()
        self.user = config['user']
        self.password = config['password']
        self.wait_time = int(config['wait_time'])
        proxy_host = config['http_proxy_host'].strip()
        proxy_user = config['http_proxy_user'].strip()
        proxy_password = config['http_proxy_password']
        group = config['group']
        proxy_filter = ''
        if config['oauth_url'].strip() != '':
            self.oauth_url = config['oauth_url'].strip()
        
        self.request_proxy_list = {}
        
        if proxy_host is not '':
            if proxy_user is not '':
                self.request_proxy_list = {'http': f'http://{proxy_user}:{proxy_password}@{proxy_host}/', 'https': f'https://{proxy_user}:{proxy_password}@{proxy_host}/'}
            else:
                self.request_proxy_list = {'http': f'http://{proxy_host}/', 'https': f'https://{proxy_host}/'}
        
        if 'SAML' in self.auth_method:
            # Check username is a machine user which is an e-mail
            if re.match('^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$', self.user) == None:
                logger.error('Selected SAML but did not provide a machine user')
                raise ConfigException('You have selected SAML authentication which requires a machine user in e-mail format provided by Apigee')
                
            if self.saml_zone == '':
                raise ConfigException('You have selected SAML authentication which requires a zone. Please enter a SAML zone')
            
        #if 'base_url' in config and config['base_url'].strip() != '':
        #    self.base_url = config['base_url']
        if config['proxies'].strip() != '':
            proxy_filter = config['proxies'].strip().split(',',MAX_RESULTS-1)
            proxy_filter = [f"'{item.strip()}'" for item in proxy_filter]
            proxy_filter = f'&filter=(apiproxy in {",".join(proxy_filter)})'
        
        if config['sort_by'] == 'Hightest message count':
            sort_by = 'sum(message_count)&sort=DESC'
        elif config['sort_by'] == 'Highest proxy errors':
            sort_by = 'sum(is_error)&sort=DESC'
        elif config['sort_by'] == 'Highest throughput':
            sort_by = 'tps&sort=DESC'
        elif config['sort_by'] == 'Highest latency':
            sort_by = 'avg(request_processing_latency)&sort=DESC'
        else:
            sort_by = 'avg(total_response_time)&sort=DESC'
            
        g1 = self.topology_builder.create_group(f'Apigee - {group}', f'Apigee - {group}')
        self.e1 = g1.create_element(f'Apigee - {group} - {self.org}/{self.env}', f'Apigee - {group} - {self.org}/{self.env}')
        self.e1.report_property('Plugin version', kwargs['json_config']['version'])
        
        # Get DNS for Apigee proxies
        dns_domain = f'{self.org}-{self.env}.apigee.net'
        try:
            dns_ip = socket.gethostbyname(dns_domain)
            self.e1.add_endpoint(dns_ip, port_list=[80,443])
        except socket.error as e:
            logger.error(f'Cannot get DNS for {dns_domain}: {e}')
        
        # Takes at least 10 minute to register performance data
        now = datetime.utcnow()
        timerange_start = now-timedelta(minutes=self.wait_time)
        timerange_end = now-timedelta(minutes=self.wait_time-1)
        
        select_proxy_metrics = ','.join(list(self.proxy_metrics))
        url_proxy = f'{self.base_url}/v1/o/{self.org}/e/{self.env}/stats/apiproxy?select={select_proxy_metrics}&timeUnit=minute&timeRange={timerange_start.strftime("%m/%d/%Y %H:%M")}~{timerange_end.strftime("%m/%d/%Y %H:%M")}&topk={MAX_RESULTS}&sortby={sort_by}{proxy_filter}'
        logger.info(f'url_proxy: {url_proxy}')
        result_proxy = self.get_api_response(url_proxy)
        logger.info(f'result: {result_proxy}')
        
        self.iterate_response(result_proxy, self.proxy_metrics)
                
        select_target_metrics = ','.join(list(self.target_metrics))        
        url_target = f'{self.base_url}/v1/o/{self.org}/e/{self.env}/stats/target?select={select_target_metrics}&timeUnit=minute&timeRange={timerange_start.strftime("%m/%d/%Y %H:%M")}~{timerange_end.strftime("%m/%d/%Y %H:%M")}&limit={MAX_RESULTS}'
        
        logger.info(f'url_target: {url_target}')
        result_target = self.get_api_response(url_target)
        logger.info(f'result: {result_target}')
        
        self.iterate_response(result_target, self.target_metrics)
        logger.info(f'Finished polling to Apigee {self.org}')

    def iterate_response(self, results, collection_metrics):
        if results:
            if 'environments' in results:
                for environment in results['environments']:
                    if 'dimensions' in environment:
                        for dimension in environment['dimensions']:
                            for metrics in dimension['metrics']:
                                if metrics['name'] in collection_metrics:
                                    self.e1.absolute(key=collection_metrics[metrics['name']]['metric_name'], value=float(metrics['values'][0]['value']), dimensions={collection_metrics[metrics['name']]['split_name']: dimension['name']})
                        logger.info(f"Reported metrics for {len(environment['dimensions'])} dimensions")
                    else:
                        self.report_custom_info_event(f'No performance data available on Apigee in the last {self.wait_time} minutes. No metrics to report. Try adjusting the wait time on plugin configuration screen.', 'No performance data on Apigee')
                        logger.info('Skipping. Found no metrics')
        else:
            raise ConfigException('Failed to get data from Apigee. Check plugin logs for more data')
            
    def get_api_response(self, url):
        try:
            response = None
            if self.auth_method == 'Basic':
                logger.info('Polling with Basic authentication')
                response = requests.get(url, auth=HTTPBasicAuth(self.user, self.password), proxies=self.request_proxy_list, timeout=15)
            elif self.auth_method == 'OAuth2':
                logger.info('Polling with OAuth2')
                if self.get_token(self.oauth_url):
                    response = requests.get(url, headers={'Authorization': f"Bearer {self.tokens[self.org]['token']}"}, proxies=self.request_proxy_list, timeout=15)
            elif 'SAML' in self.auth_method:
                logger.info('Polling with SAML')
                if self.get_token(f'https://{self.saml_zone}.login.apigee.com/oauth/token'):
                    response = requests.get(url, headers={'Authorization': f"Bearer {self.tokens[self.org]['token']}"}, proxies=self.request_proxy_list, timeout=15)
            else:
                # No Authentication
                response = requests.get(url, proxies=self.request_proxy_list, timeout=15)
            #logger.info(f'Response code: {response.status_code}')
        except requests.exceptions.RequestException as e:
            logger.exception(f'Failed polling: {url}. {e}')
            return False # The request failed
        
        if response and response.status_code == 200:
            return response.json()
        else:
            #self.e1.report_custom_info_event(f'Failed to get data from Apigee. Error code returned: {response.status_code}. Error: {response.text}', 'Failed to get data from Apigee')
            #logger.error(f'Failed to poll Apigee. Error code returned: {response.status_code}. Error: {response.text}')
            logger.error(f'Failed to poll Apigee. An error occurred. Response: {response}')
            return False
        
    def get_token(self, url):
        if self.org not in self.tokens:
            self.tokens[self.org] = {}
        if 'token_time' in self.tokens[self.org]:
            now = time.time()
            # A token expires every 30 minutes, and a refresh_token has a different expiry time.
            # So every 30 minutes we need to refresh our current token and every so often according to expire_in 
            # we need to re-authenticate with credentials and get a whole new token set.
            if now-self.tokens[self.org]['token_time'] > 1739 and now-self.tokens[self.org]['refresh_token_time'] <= self.tokens[self.org]['refresh_token_expiry']-60:
                grant_type = 'refresh_token'
            elif now-self.tokens[self.org]['refresh_token_time'] > self.tokens[self.org]['refresh_token_expiry']-60:
                grant_type = 'password'
            else:
                return self.tokens[self.org]['token']
        else:        
            grant_type = 'password'
            
        if grant_type is not None:
            headers = {'Content-Type': 'application/x-www-form-urlencoded',
                        'Accept': 'application/json;charset=utf-8',
                        'Authorization': 'Basic ZWRnZWNsaTplZGdlY2xpc2VjcmV0'}
                        
            if grant_type == 'refresh_token':
                form_data = {'grant_type': grant_type,
                    'refresh_token': self.tokens[self.org]['refresh_token']}
            else:
                form_data = {'username': self.user,
                    'password': self.password,
                    'grant_type': grant_type}
        
            try:
                result = requests.post(url, headers=headers, proxies=self.request_proxy_list, data=form_data, timeout=20)
                #logger.info(f'Token result: {result.json()}')
                if result.status_code == 200:
                    content = result.json()
                    
                    if 'access_token' in content:
                        self.tokens[self.org]['token'] = content['access_token']
                        self.tokens[self.org]['token_time'] = time.time()
                        self.tokens[self.org]['refresh_token'] = content['refresh_token']
                        if grant_type == 'password':
                            self.tokens[self.org]['refresh_token_time'] = time.time()
                            self.tokens[self.org]['refresh_token_expiry'] = content['expires_in']
                        
                        return self.tokens[self.org]['token']
                else:
                    logger.error(f'Failed to authenticate via OAuth to {self.oauth_url}. Error code returned: {result.status_code}. Error: {result.text}')
                    # Add custom info that failed to get token
                    self.e1.report_custom_info_event(f'Failed to authenticate using OAuth. Error code returned: {result.status_code}. Error: {result.text}', 'Failed to authenticate')
                    return False
                
            except requests.exceptions.RequestException as e:
                logger.exception(f'Failed to authenticate with OAuth. URL: {self.oauth_url}. {e}')
            return False # The request failed
    
    def report_custom_info_event(self, message, title):
        if self.events < MAX_EVENTS:
            if title + message not in self.previousEvents:
                self.events += 1
                self.e1.report_custom_info_event(message, title)
                self.previousEvents.append(title + message)