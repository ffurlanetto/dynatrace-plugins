import logging
from ruxit.api.base_plugin import BasePlugin
from ruxit.api.exceptions import ConfigException, AuthException
from ruxit.api.snapshot import pgi_name
import subprocess
import os
import collections
from ruxit.api.selectors import EntityType, ExplicitSelector
from ruxit.api.data import MEAttribute
from argparse import Action




logger = logging.getLogger(__name__)
#logger.info(__name__)


# This plugin calls the tibemsadmin command via a script

# The data is not fixed size so the code needs to extract the column start and end index.
# When the first fields is detected, the data starts on the next line so skip until queues_fieldNames[0] is detected
# See example:

#TIBCO Enterprise Message Service Administration Tool.
#Copyright 2003-2019 by TIBCO Software Inc.
#All rights reserved.
#
#Version 8.5.1 V4 9/12/2019
#
#Connected to: tcp://localhost:7222
#tcp://localhost:7222> show queues
#                                                                                            All Msgs            Persistent Msgs
#  Queue Name                                                      SNFGXIBCT  Pre  Rcvrs     Msgs    Size        Msgs    Size
#  >                                                               ---------    5*     0        0     0.0 Kb        0     0.0 Kb
#  $sys.admin                                                      +--------    5*     0        0     0.0 Kb        0     0.0 Kb
#  $sys.lookup                                                     ---------    5*     0        0     0.0 Kb        0     0.0 Kb
#  $sys.redelivery.delay                                           +--------    5*     0        0     0.0 Kb        0     0.0 Kb
#  $sys.undelivered                                                +--------    5*     0        0     0.0 Kb        0     0.0 Kb
#* $TMP$.EMS-SERVER.46805E2026EB3.1                                ---------    5      1        0     0.0 Kb        0     0.0 Kb
#* mygiganticqueuenamewhichhelpsmetestmaximumwidthofthenamecolumn  ---------    5*     0       15     3.8 Kb       15     3.8 Kb
#  queue.sample                                                    ---------    5*     0        0     0.0 Kb        0     0.0 Kb
#  sample                                                          ---------    5*     0        0     0.0 Kb        0     0.0 Kb
#* sample queue                                                    ---------    5*     0        1     0.2 Kb        1     0.2 Kb
#* testQueue                                                       ---------    5*     0        1     0.2 Kb        1     0.2 Kb

# structure to list the name of the header and it's start and end index for data extraction
Header = collections.namedtuple('Header',['name','begin','end'])

# structure to retrieve a given column index and the name of the metric
DataToPull = collections.namedtuple('DataToPull', ['index','metricName'])


# name of the headers including spaces for extracting the data correctly
queues_fieldNames = ["Queue Name","SNFGXIBCT"," Pre","Rcvrs","   Msgs","  Size","   Msgs","  Size"]
# index of the fields to pull out from the data and their associated metric name.
queues_RequiredFields = [ DataToPull(3,"EMS2.QueueReceivers"), DataToPull(4, "EMS2.QueueDepth"),DataToPull(5, "EMS2.QueueMsgSize")]

messageRate_fieldNames = ["Queue Name", "      Msgs", "  Size", "  Msgs", "  Size", "      Msgs", "  Size", "  Msgs", "  Size"]
messageRate_RequiredFields = [ DataToPull(3,"EMS2.QueueInboundMsgRate"), 
                              DataToPull(4,"EMS2.QueueInboundMsgSizeRate"), DataToPull(7,"EMS2.QueueOutboundMsgRate"), 
                              DataToPull(8,"EMS2.QueueOutboundMsgSizeRate")]

topics_fieldNames = ["Topic Name", "SNFGEIBCTM", " Subs", " Durs", "   Msgs", "  Size", "  Msgs", "  Size"]
topics_RequiredFields = [DataToPull(4, "EMS2.TopicMsgDepth"), DataToPull(5, "EMS2.TopicMsgSize")]

topicsRate_fieldNames = ["Topic Name", "      Msgs", "  Size", "  Msgs", "  Size", "      Msgs", "  Size", "  Msgs", "  Size"]
topicsRate_RequiredFields = [  DataToPull(3,"EMS2.TopicInboundMsgRate"), 
                             DataToPull(4,"EMS2.TopicInboundMsgSizeRate"), DataToPull(7,"EMS2.TopicOutboundMsgRate"), 
                             DataToPull(8,"EMS2.TopicOutboundMsgSizeRate")]


adminExe = "tibemsadmin"

maxItemsConst = 100

class tibcoEMS(BasePlugin):
    
    def initialize(self, **kwargs):

        # get the process properties as we are not using singleton, there will be an instance of the plugin for each process matching the predicate per host.
        config = kwargs['config']
   
        activation_context = kwargs['activation_context']
        if len(activation_context.value.processes) > 1:
            logger.info("EMS: Detected more than 1 process instance")
         

        exePath = activation_context.value.processes[0].properties['ExePath']
        
        # get listener address from snapshot as not all instances listen on localhost only.
        portBindings = activation_context.value.processes[0].properties['PortBindings']
        if portBindings.find("_") == -1:
            raise ConfigException ("Couldn't retrieve port Bindings")
        else:
            # with two listeners, reading the first value should be enough
            listenAddress = portBindings.split("_")[0]
        
     
        
        # use the exePath to find where tibemsAdmin should be located. Strip out the tibemsd from the path
        osSep = os.path.sep
        position = exePath.rfind(osSep)
        if position != -1:
            self.workdir = exePath[0:position]
        else:
            raise ConfigException("Couldn't detect ExePath from process snapshot:" + exePath)

        self.processGroup_id = str(activation_context.value.group_instance_id)

        self.firstRun = True
               
        if config["auth_user"].strip() == '':
            raise ConfigException("User field cannot be empty")
        else:    
            self.auth_user = config["auth_user"]  

        self.auth_password = config["auth_password"]
        
        if config["secure"] == "No":
            self.secure ="tcp"
        else:
            self.secure = "ssl"
        
        # list of queues to ignore
        # doesn't expect an exact match but only start of the string
        self.excl_queues = config["excl_queues"].split(',')
        
        # list of topics to ignore
        self.excl_topics = config["excl_topics"].split(',')
        
        self.maxItems = maxItemsConst
       
        self.serverAddress = self.secure + "://" + listenAddress 
        
        # build a list of valid ports
        self.instances = self.findValidPorts(activation_context)
           
        logger.info("Instances" + str(self.instances))

        
        
        # check that we can connect to the server and get basic properties
        # if not, raise a configuration Exception to notify the UI
        for instance in self.instances:
            logger.info(f"EMS: Getting properties for instance {instance}")
            self.run_getProperties(instance) 
    
    
            
    # Field format "4.5 Kb or 4.5 MB or 4.5 GB"
    # Converts to float in kilobytes  
    # if unit not detected returns value as is     
    def convertToKb(self, value):
        if value.find("Kb") > 0:
            value = value.replace("Kb", "")
            return value.strip()

        if value.find("MB") > 0:
            value = value.replace("MB", "")
            return str(float(value.strip())*1024)
            
        if value.find("GB") > 0:
            value = value.replace("GB", "")            
            return str(float(value.strip())*1024*1024)
        
        # if no size found return as is
        logger.info("EMS: convertToKb couldn't convert " + value)
        return value
    
    
    # Takes a string of the following format and returns a percentage
    # "15.2 Kb out of 512MB"
    # if format not detected returns 0
    def convertToPercentage(self, value):
        values = value.split(" out of ")
        if len(values) == 2:
            return float(self.convertToKb(values[0]))/float(self.convertToKb(values[1]))*100
        else:
            logger.info("EMS: convertToPercentage couldn't convert " + value)
            return 0    
    
    # extract first value from "0 msgs/sec,  0.0 Kb per second" or
    # "0 reads/sec,  0.0 Kb per second"
    # The separator is the string to look out for so msgs/sec or reads/sec
    
    def extractMsgRate(self, value, separator):
        values = value.split(separator)
        if len(values) == 2:
            return values[0]
        else:
            logger.info("EMS: extractMsgRate couldn't extract " + value)
            return 0
        
    
    # extract second value from "0 msgs/sec,  0.0 Kb per second"    
    def extractMsgSizeRate(self, value):
        tempValue = value.split(", ")
        if len(tempValue)==2:
           return self.convertToKb(tempValue[1].split(" per")[0]) 
        else:
            logger.info("EMS: extractMsgSizeRate couldn't extract " + value)
    
    # check that the value is a substring of one of the values contained in the exclusion list
    def skipItem(self, value, exclusionList):
        for item in exclusionList:
            if item.strip()!= "" and value.find(item.strip()) != -1:
                return True
        return False
      
      
    # Run emsadmin command for a scriptFile
    # return None if failed or output if successful  
    def run_emsCommand(self, scriptFile, instancePort):
        
        instanceAddress = self.serverAddress + ":" + instancePort
        admin_output = None
        cmd_emsAdmin = os.path.join(self.workdir, adminExe)
        try:
            admin_output = subprocess.run([cmd_emsAdmin, "-server", instanceAddress, "-user", self.auth_user, "-password", self.auth_password, 
                                           "-script", os.path.abspath(os.path.join(os.path.dirname(__file__), scriptFile))], 
                                           stdout=subprocess.PIPE, universal_newlines=True)
            admin_output.check_returncode()
            return admin_output
        
        except Exception as ex:
            mypid = self.processGroup_id
            logger.info(f"EMS: Couldn't run command {cmd_emsAdmin} for script: {scriptFile} : process: {mypid} : {ex}")  
            if admin_output != None:
                logger.info(f"EMS: {admin_output.stdout}")                    
        return None
        
        
    # get broker level metrics via show server command   
    def run_ShowServer(self, instancePort):
        cmd_success= False 
        serverValues = dict()
        admin_output = None
        
        try:
            admin_output = self.run_emsCommand("server.txt" , instancePort)
            if admin_output != None:
                for line_item in admin_output.stdout.splitlines():
                    if cmd_success == False:
                        if line_item.find("Server:")==1:
                            cmd_success = True
                            # format is Server:       EMS-SERVER (version: 8.5.1 V4)
                            keyPair = line_item.split("version:")
                            serverValues["Server"] = keyPair[1].strip()[:-1]
                    else:
                        keyPair = line_item.split(":")
                        serverValues[keyPair[0].strip()] = keyPair[1].strip() 
                            
                if cmd_success == False:
                    logger.info("EMS: show server didn't return the expected results for server " + admin_output.stdout + " on GID=" + self.processGroup_id)
                else:
                    #logger.info("EMS: show server gid=" + self.processGroup_id + ", dict=" + str(serverValues))
                    # format is Topics:                   5 (0 dynamic, 0 temporary)
                    # so only read the first number
                    self.results_builder.absolute(key='EMS2.BrokerTopicCount',value=serverValues['Topics'].split()[0], dimensions={'instance' : instancePort})
                    # same as above
                    self.results_builder.absolute(key='EMS2.BrokerQueueCount',value=serverValues['Queues'].split()[0], dimensions={'instance' : instancePort})
                    
                    # format is key: 0
                    self.results_builder.absolute(key='EMS2.BrokerClientCount',value=serverValues['Client Connections'], dimensions={'instance' : instancePort})
                    self.results_builder.absolute(key='EMS2.BrokerSessionCount',value=serverValues['Sessions'], dimensions={'instance' : instancePort})
                    self.results_builder.absolute(key='EMS2.BrokerProducerCount',value=serverValues['Producers'], dimensions={'instance' : instancePort})
                    self.results_builder.absolute(key='EMS2.BrokerConsumerCount',value=serverValues['Consumers'], dimensions={'instance' : instancePort})
                    self.results_builder.absolute(key='EMS2.BrokerPendingMsgCount',value=serverValues['Pending Messages'], dimensions={'instance' : instancePort})
                    
                    # format is Pending Message Size:     4.5 Kb
                    self.results_builder.absolute(key='EMS2.BrokerPendingMsgSize',value=(self.convertToKb(serverValues['Pending Message Size'])), dimensions={'instance' : instancePort})   
                    
                    # format is Message Memory Usage:     15.2 Kb out of 512MB                             
                    self.results_builder.absolute(key='EMS2.BrokerMemoryUsage',value=(self.convertToPercentage(serverValues['Message Memory Usage'])), dimensions={'instance' : instancePort})
                    
                    self.results_builder.absolute(key='EMS2.BrokerMemoryPooled',value=(self.convertToKb(serverValues['Message Memory Pooled'])), dimensions={'instance' : instancePort})                                
                    self.results_builder.absolute(key='EMS2.BrokerSynchronousStorage',value=(self.convertToKb(serverValues['Synchronous Storage'])), dimensions={'instance' : instancePort})
                    self.results_builder.absolute(key='EMS2.BrokerAsyncStorage',value=(self.convertToKb(serverValues['Asynchronous Storage'])), dimensions={'instance' : instancePort})
                    
                    # format is Inbound Message Rate:     0 msgs/sec,  0.0 Kb per second
                    # so produce 2 metrics out of this value   
                    self.results_builder.absolute(key='EMS2.BrokerInboundMsgCountRate',value=(self.extractMsgRate(serverValues['Inbound Message Rate']," msgs/sec")), dimensions={'instance' : instancePort})
                    self.results_builder.absolute(key='EMS2.BrokerInboundMsgSizeRate',value=(self.extractMsgSizeRate(serverValues['Inbound Message Rate'])), dimensions={'instance' : instancePort})                                                
                    self.results_builder.absolute(key='EMS2.BrokerOutboundMsgCountRate',value=(self.extractMsgRate(serverValues['Outbound Message Rate'], " msgs/sec")), dimensions={'instance' : instancePort})                                                
                    self.results_builder.absolute(key='EMS2.BrokerOutboundMsgSizeRate',value=(self.extractMsgSizeRate(serverValues['Outbound Message Rate'])), dimensions={'instance' : instancePort})                                                
                    self.results_builder.absolute(key='EMS2.BrokerStorageReadCountRate',value=(self.extractMsgRate(serverValues['Storage Read Rate']," reads/sec")), dimensions={'instance' : instancePort})                                                
                    self.results_builder.absolute(key='EMS2.BrokerStorageReadSizeRate',value=(self.extractMsgSizeRate(serverValues['Storage Read Rate'])), dimensions={'instance' : instancePort})                                                
                    self.results_builder.absolute(key='EMS2.BrokerStorageWriteCountRate',value=(self.extractMsgRate(serverValues['Storage Write Rate']," writes/sec")), dimensions={'instance' : instancePort})                                                
                    self.results_builder.absolute(key='EMS2.BrokerStorageWriteSizeRate',value=(self.extractMsgSizeRate(serverValues['Storage Write Rate'])), dimensions={'instance' : instancePort})                                                
    
                    # states are listed here: https://docs.tibco.com/pub/emsah/3.0.3/doc/html/GUID-C70B8FAD-6609-49FB-B3D2-CE6968EA8ED9.html
                    self.results_builder.state_metric(key='node_status', value=serverValues['State'], dimensions={'instance' : instancePort})  
    
                    self.results_builder.report_property(key="Version", value=serverValues['Server'], me_attribute=MEAttribute.CUSTOM_PG_METADATA)                                              
                
        except Exception as ex:
            logger.info("EMS: Couldn't run show server:" + str(ex))  
            
    
    def run_getProperties(self, instancePort):
        cmd_success= False 
        configValues = dict()
        admin_output = None
        admin_output = self.run_emsCommand("config.txt", instancePort)
        if admin_output != None:
            for line_item in admin_output.stdout.splitlines():
                if cmd_success == False:
                    if line_item.lower().find("configuration file:")>0:
                        cmd_success = True
                else:
                    # there are lines with comments starting with #
                    if line_item.find('#')!= 0:
                        keyPair = line_item.split("=")
                        configValues[keyPair[0].strip()] = keyPair[1].strip() 
                    
            if cmd_success == False:
                logger.info("EMS: show config didn't return the expected results for server " + admin_output.stdout + " on instance=" + instancePort)
                raise ConfigException("Cannot get version number from server as tibemsadmin failed, check log for further information")
            else:
  
                if configValues['statistics'] == "disabled":
                    raise ConfigException("Statistics are NOT enabled on instance " + instancePort)
                else:
                    self.results_builder.report_property(key="Statistics", value=configValues['statistics'], me_attribute=MEAttribute.CUSTOM_PG_METADATA)
                    #logger.info("EMS: show config gid=" + self.processGroup_id + ", dict=" + str(configValues))
                    
                    '''self.results_builder.report_property(key="Maximum Connections", value=configValues['max_connections'], me_attribute=MEAttribute.CUSTOM_PG_METADATA)
                    self.results_builder.report_property(key="Multicast Enabled", value=configValues['multicast'], me_attribute=MEAttribute.CUSTOM_PG_METADATA)  
                    self.results_builder.report_property(key="Routing Enabled", value=configValues['routing'], me_attribute=MEAttribute.CUSTOM_PG_METADATA)
                    self.results_builder.report_property(key="Authorization Enabled", value=configValues['authorization'], me_attribute=MEAttribute.CUSTOM_PG_METADATA)         
                    self.results_builder.report_property(key="Flow Control Enabled", value=configValues['flow_control'], me_attribute=MEAttribute.CUSTOM_PG_METADATA)                            
                    self.results_builder.report_property(key="Fault Tolerant Heartbeat", value=configValues['ft_heartbeat'], me_attribute=MEAttribute.CUSTOM_PG_METADATA)
                    self.results_builder.report_property(key="Fault Tolerant reconnect timeout", value=configValues['ft_reconnect_timeout'], me_attribute=MEAttribute.CUSTOM_PG_METADATA)                       
                    self.results_builder.report_property(key="Fault Tolerant Reread", value=configValues['ft_failover_reread'], me_attribute=MEAttribute.CUSTOM_PG_METADATA)  
                    self.results_builder.report_property(key="Swapping Enabled", value=configValues['msg_swapping'], me_attribute=MEAttribute.CUSTOM_PG_METADATA)  
                    self.results_builder.report_property(key="Reserve Memory", value=configValues['reserve_memory'], me_attribute=MEAttribute.CUSTOM_PG_METADATA)  
                    self.results_builder.report_property(key="Maximum Log File Size", value=configValues['logfile_max_size'], me_attribute=MEAttribute.CUSTOM_PG_METADATA)  
                    self.results_builder.report_property(key="Maximum Message Memory", value=configValues['max_msg_memory'], me_attribute=MEAttribute.CUSTOM_PG_METADATA)  
                    self.results_builder.report_property(key="Client Heartbeat Server Interval", value=configValues['client_heartbeat_server'], me_attribute=MEAttribute.CUSTOM_PG_METADATA)  
                    self.results_builder.report_property(key="Client Timeout Server Connection", value=configValues['client_timeout_server_connection'], me_attribute=MEAttribute.CUSTOM_PG_METADATA)  
                    self.results_builder.report_property(key="Fault Tolerant Activation Time", value=configValues['ft_activation'], me_attribute=MEAttribute.CUSTOM_PG_METADATA)                  
                    self.results_builder.report_property(key="Maximum Statistics Memory", value=configValues['max_stat_memory'], me_attribute=MEAttribute.CUSTOM_PG_METADATA)                  
                    self.results_builder.report_property(key="Server Heartbeat Client Interval", value=configValues['server_heartbeat_client'], me_attribute=MEAttribute.CUSTOM_PG_METADATA)  
                    self.results_builder.report_property(key="Server Heartbeat Server Interval", value=configValues['server_heartbeat_server'], me_attribute=MEAttribute.CUSTOM_PG_METADATA)
                    self.results_builder.report_property(key="Server Timeout For Server Connection", value=configValues['server_timeout_server_connection'], me_attribute=MEAttribute.CUSTOM_PG_METADATA)                                    
                    self.results_builder.report_property(key="Server Timeout For Client Connection", value=configValues['server_timeout_client_connection'], me_attribute=MEAttribute.CUSTOM_PG_METADATA)'''                                                      
                                                                                             
        else:                                        
            raise ConfigException("Cannot get version number from server as tibemsadmin failed, check log for further information")
            logger.info("Cannot get version number from server as tibemsadmin failed")
            
     
        

    # function to execute tibemsadmin commands such as show queues, show topics.
    # scriptPath is the name of the script to execute
    # headers is a list of all the headers. The first one will be used to validate that the output is correct.
    # fieldList is a tuple of indexes and metric name to extract specific fields from the table
    # dimension is the name of the dimension for splitting
    # excludeNames is a list of substrings to ignore for the queue/topic name
    def run_TibEmsAdmin(self, scriptPath, headers, fieldList, dimension, excludeNames, instancePort):

        cmd_success = False
        admin_output = None
        
        try:
            
            admin_output = self.run_emsCommand(scriptPath, instancePort)
            if admin_output != None:            
                headers_offset = None
                numOfItems = 0
                
                myData = []
                
                # Detect headers
                for line_item in admin_output.stdout.splitlines():
                    # check that the command executed fine by looking for a header name
                    if cmd_success == False:
                        fieldOneOffset = line_item.find(headers[0]) 
                        if fieldOneOffset >=0:
                            cmd_success = True
                            logger.info("EMS: script=" + scriptPath + ", headers=" + str(line_item))
                            # as column names are repeated always steps forward to avoid returning the same field.
                            offset = 0
                            for index in range(0,len(headers)):
                                # the first field doesn't always starts from position 0, for instance show queues starts from pos 2
                                # builds a list of headers: name, begin index and end index to extract the info
                                if index == 0:
                                    prev = line_item.index(headers[1])-1
                                    headers_offset = [Header(headers[index],fieldOneOffset, prev)]
                                else:
                                    begin_index = line_item.index(headers[index],offset)
                                    offset = begin_index-1
                                    if index+1 == len(headers):
                                        end_index = len(line_item)
                                    else:
                                        end_index = line_item.index(headers[index+1],offset)
                                    headers_offset.append(Header(headers[index],begin_index,end_index))
                            #logger.info("EMS: gid=" + self.processGroup_id + ", script=" + scriptPath + ", offsets= " + str(headers_offset))
                            
                    else:   
                        # check if item should be skipped
                        # items to ignore start with $ or contain ">" (> <total>)
                        
                        item_name = line_item[headers_offset[0].begin:headers_offset[0].end].strip()
                         
                        if item_name.find(">")== -1 and not item_name.startswith("$") and self.skipItem(item_name, excludeNames) == False:
                            # add to a list because all the functions return the same data but not in the same order!
                            myData.append(line_item)
                            
                # process the sorted data to allow max split detection code to work on the same items            
                if cmd_success == True and len(myData)>0:
                    for line_item in sorted(myData):            
                        numOfItems+=1
                        # cannot record more than 100 splits.
                        if numOfItems < self.maxItems+1:
                            #let's read the value from the table by using the offset for each header and the list of required fields
                            item_name = line_item[headers_offset[0].begin:headers_offset[0].end].strip()
                            for field in fieldList:
                                columnIndex = field.index
                            
                                value = line_item[headers_offset[columnIndex].begin:headers_offset[columnIndex].end].strip()
                                # size fields are followed by the unit so remove items if necessary
                                if value.find(" Kb") > 0 or value.find(" MB") > 0 or value.find(" GB") > 0:
                                    value = self.convertToKb(value)

                                #logger.info(item_name+ ":" + value + ":" + dimension + ":" + instancePort)
                                self.results_builder.absolute(key=field.metricName,value=value, dimensions={dimension : item_name, 'server' : instancePort})
                        else:
                            logger.info("EMS: exceeded max splits for " + scriptPath)
                            break
                        
                if cmd_success == False:
                    if admin_output != None:
                        logger.info("EMS: unexpected output from command " + scriptPath + ":" + admin_output.stdout )
                    else:
                        logger.info ("EMS: command didn't even run for " + scriptPath)

        
        except Exception as ex:
            logger.info("EMS: Couldn't run emsadmin for " + scriptPath + ", " + str(ex))  
         


    # try all the ports until is connects ok. Some installation use 2 ports.
    # checks how many processes are detected and then check each port
    def findValidPorts(self, activation_context):
        instances = []   
        
        for index in activation_context.value.processes:
            # when 2 listeners are defined it returns 2 ports.
            myPorts = index.properties['ListeningPorts']
            myportList = myPorts.split()
            foundValidPort = False
            for ports in myportList:
                output = self.run_emsCommand("empty.txt", ports)
                if output is not None and output.stdout.find("Connected to"):
                    instances.append(ports)
                    foundValidPort = True
                    break
            if foundValidPort == False:
                logger.info("Instance couldn't be connected to")
        return instances
                                          
    
    def query(self, **kwargs):
        
        # re-process the process list in case something changed
        self.instances = self.findValidPorts(kwargs['activation_context'])
           
        logger.info("Instances:" + str(self.instances))
        
        #self.instances.append(myportList[0])              
        
        # can only monitor 100/instances queues
        if len(self.instances)>0:
            self.maxItems = int(maxItemsConst/len(self.instances))
        else:
            self.maxItems = 100
        
        

        # retrieve the broker level data for all instances
        for instance in self.instances:
            logger.info(f"EMS: Executing command for instance: {instance}")
            self.run_ShowServer(instance)
        
            self.run_TibEmsAdmin("queues.txt", queues_fieldNames, queues_RequiredFields, "queue", self.excl_queues, instance)              
            self.run_TibEmsAdmin("topics.txt", topics_fieldNames, topics_RequiredFields, "topic", self.excl_topics, instance)
            self.run_TibEmsAdmin("queuesRate.txt", messageRate_fieldNames, messageRate_RequiredFields, "queue", self.excl_queues, instance)
            self.run_TibEmsAdmin("topicsRate.txt", topicsRate_fieldNames, topicsRate_RequiredFields, "topic", self.excl_topics, instance)
         
        


