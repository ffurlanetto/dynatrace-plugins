import json
import re
from ruxit.api.base_plugin import RemoteBasePlugin
import logging
import pymqi
import socket
from multiprocessing.pool import ThreadPool
import math
import time
import fnmatch
from datetime import datetime
import requests
from ruxit.api.exceptions import AuthException, ConfigException
from pymqi.CMQC import *
from pymqi.CMQCFC import *


logger = logging.getLogger(__name__)
MAX_RESULTS = 100
MAX_THREADS = 25
MAX_EVENTS = 99

class EncodeText(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, (bytes, bytearray)):
            return obj.decode('ASCII')
        # Let the base class default method raise the TypeError
        return json.JSONEncoder.default(self, obj)
        
class CustomIBMMQPluginRemote(RemoteBasePlugin):
    last_topology_retrieve = {}
    # Used for threading
    start = 0
    maxBatchItems = 35
    firstExecution = True
    refreshItemNames = True
    previousEvents = []
    events = 0
    queue_manager = None
    
    # Declaration so we don't get queue names every time it polls
    qItems = []
    cItems = []
    OS = {3: 'AIX/Unix', 4: 'IBM i Series', 5: 'Microsoft Windows', 11: 'Microsoft Windows NT', 1: 'z/OS', 13: 'HP Integrity NonStop Server',
         12: 'OpenVMS', 2: 'OS/2', 23: 'z/TPF', 27: 'z/VSE', 28: 'MQ Appliance'}
         
    channel_states = {MQCHS_BINDING: 'Binding',
                        MQCHS_STARTING: 'Starting',
                        MQCHS_RUNNING: 'Running',
                        MQCHS_PAUSED: 'Paused',
                        MQCHS_RETRYING: 'Retrying',
                        MQCHS_STOPPED: 'Stopped',
                        MQCHS_STOPPING: 'Stopping',
                        MQCHS_REQUESTING: 'Requesting',
                        MQCHS_SWITCHING: 'Switching',
                        MQCHS_INITIALIZING: 'Initializing'}
    
    # Store metrics that need their positive/negative delta calculated
    metricHolder = {}
    
    timeSinceLastRetrieve = time.time()
    
    def query(self, **kwargs):
        config = kwargs['config']
        
        if self.firstExecution or config['debug']:
            logging.basicConfig(level=logging.DEBUG)
            logger.setLevel(logging.DEBUG)
        else:
            logger.setLevel(logging.INFO)
            
        self.start = time.time()
        
        # Config GUI vars
        host_port = config['host_port'].strip()
        group = config.get('group', 'Default group').strip()
        queueManager = config['queue_manager'].strip()
        channels = config['channel'].strip()
        server_connection = config['server_connection'].strip()
        listeners = config['listener'].strip()
        key_repo_location = config['key_repo_location'].strip()
        lastMsgDate, lastMsgTime = None, None
        queues, channels, listeners = {}, {}, {}
        currentQueueDepth, maxQueueDepth = None, None
        cipherSpec = config['cipher_spec'].strip()
        excludeSystem = True if 'exclude_system' in config and str(config['exclude_system']).lower() == 'true' else False
        runResetStats = True if 'reset_q_stats' in config and str(config['reset_q_stats']).lower() == 'true' else False
        proxy_host = config.get('http_proxy_host', '').strip()
        proxy_user = config.get('http_proxy_user', '').strip()
        proxy_password = config.get('http_proxy_password', '')
        dlq_alert = True if 'dlq_alert' in config and str(config['dlq_alert']).lower() == 'true' else False
        retry_channel_alert = True if 'retry_channel_alert' in config and str(config['retry_channel_alert']).lower() == 'true' else False
        self.request_proxy_list = {}
        
        if queueManager not in self.last_topology_retrieve:
            self.last_topology_retrieve[queueManager] = {'time': 0}
            
        logger.info(f'Polling to {queueManager} started')

        if queueManager == '':
            raise ConfigException('Queue Manager name must not be empty')
            
        if host_port == '':
            raise ConfigException('Hostname and port of queue manager must be provided to connect')

        if key_repo_location != '' and cipherSpec == '':
            raise ConfigException('Cipher specification must not be empty')
            
        if config['get_queue_topology'] and (config['api_endpoint'].strip() == '' or config['api_token'].strip() == ''):
            raise ConfigException('You have selected to get queue topology but did not provide the cluster/tenant or the API token')
        
        # Remove any wildcard from queues and restrict number of queues to MAX_RESULTS
        if 'queues' in config and config['queues'] != '':
            queues = config['queues'].split(',',MAX_RESULTS)
            if len(queues) == MAX_RESULTS+1:
                queues.pop()
                
            #Move queues with wildcards to the end to guarantee specific ones first
            moveToStart = filter(lambda x: '*' not in x, queues)
            for item in moveToStart:
                queues.remove(item)
                queues.insert(0, item)
            queues = [x.strip() for x in queues if x is not '']
            
        if 'channel' in config and config['channel'] != '':
            channels = config['channel'].split(',',MAX_RESULTS)
            if len(channels) == MAX_RESULTS+1:
                channels.pop()
            
            #Move channels with wildcards to the end to guarantee specific ones first
            moveToStart = filter(lambda x: '*' not in x, channels)
            for item in moveToStart:
                channels.remove(item)
                channels.insert(0, item)
            channels = [x.strip() for x in channels if x is not '']
            
        if 'listener' in config and config['listener'] != '':
            listeners = config['listener'].split(',')
            listeners = [x.strip() for x in listeners if x is not '']
            
        if 'host_port' in config and config['host_port'] != '':
            hosts = config['host_port'].split(',')
        
        g1 = self.topology_builder.create_group(f'IBM MQ - {group}', f'IBM MQ - {group}')
        self.node = g1.create_element(f'IBM MQ - {group} - {queueManager}', f'IBM MQ - {group} - {queueManager}')
        self.node.report_property("Plugin version", kwargs["json_config"]["version"])
        
        if proxy_host is not '':
            if proxy_user is not '':
                self.request_proxy_list = {'http': f'http://{proxy_user}:{proxy_password}@{proxy_host}/', 'https': f'https://{proxy_user}:{proxy_password}@{proxy_host}/'}
            else:
                self.request_proxy_list = {'http': f'http://{proxy_host}/', 'https': f'https://{proxy_host}/'}
                
        # Get the host IP address
        hostList = []
        for host in hosts:
            matcher = re.search('(.+)\((\d+)\)|(.+):(\d+)',host.strip(),re.M|re.I)
            try:
                hostIP = matcher.group(1) or matcher.group(3)
                hostPort = int(matcher.group(2) or matcher.group(4))
                
                logger.info(f'Host: {hostIP}. Port: {hostPort}')
                
                hostList.append(f'{hostIP}({hostPort})')
                try:
                    hostIP = socket.gethostbyname(hostIP)
                    self.node.add_endpoint(hostIP, hostPort)
                except socket.error as e:
                    logger.error(f'Unable to resolve IP for host: {host}. Will not add endpoint')
            except Exception as e2:
                raise ConfigException(f'Hostname or IP not valid: {host}')
                logger.exception(e2)
                
        # Set the commands to run for each entity type
        qmgrCommands = ['MQCMD_INQUIRE_Q_MGR_STATUS']
        qNameCommands = ['MQCMD_INQUIRE_Q_NAMES']
        qCommands = ['MQCMD_INQUIRE_Q', 'MQCMD_INQUIRE_Q_STATUS']
        if runResetStats == True:
            qCommands.append('MQCMD_RESET_Q_STATS')
        channelCommands = ['MQCMD_INQUIRE_CHANNEL_STATUS']
        listenerCommands = ['MQCMD_INQUIRE_LISTENER_STATUS']
        
        self.qmgrMetrics, self.qMetrics, self.cMetrics, self.lMetrics = [], [], [], []
        
        # Set all metrics to retrieve
        self.qmgrMetrics.append({'name': 'QueueManager.Status', 'command': 'MQCMD_INQUIRE_Q_MGR_STATUS', 'attr': MQIACF_Q_MGR_STATUS, 'owner': 'QueueManager', 'metric': 'absolute', 'normalValue' : MQQMSTA_RUNNING})
        self.qmgrMetrics.append({'name': 'QueueManager.Connections', 'command': 'MQCMD_INQUIRE_Q_MGR_STATUS', 'attr': MQIACF_CONNECTION_COUNT, 'owner': 'QueueManager', 'metric': 'absolute'})
        
        self.qMetrics.append({'name': 'Queue.Depth', 'command': 'MQCMD_INQUIRE_Q', 'attr': MQIA_CURRENT_Q_DEPTH, 'owner': 'Queue', 'metric': 'absolute', 'splitName': 'Queue', 'splitBy': MQCA_Q_NAME})
        self.qMetrics.append({'name': 'Queue.InhibitGet', 'command': 'MQCMD_INQUIRE_Q', 'attr': MQIA_INHIBIT_GET, 'owner': 'Queue', 'metric': 'absolute', 'splitName': 'Queue', 'splitBy': MQCA_Q_NAME, 'normalValue' : 'MQQA_GET_ALLOWED'})
        self.qMetrics.append({'name': 'Queue.InhibitPut', 'command': 'MQCMD_INQUIRE_Q', 'attr': MQIA_INHIBIT_PUT, 'owner': 'Queue', 'metric': 'absolute', 'splitName': 'Queue', 'splitBy': MQCA_Q_NAME, 'normalValue' : 'MQQA_PUT_ALLOWED'})
        self.qMetrics.append({'name': 'Queue.MaxQueueDepth', 'command': 'MQCMD_INQUIRE_Q', 'attr': MQIA_MAX_Q_DEPTH, 'owner': 'Queue', 'metric': 'absolute', 'splitName': 'Queue', 'splitBy': MQCA_Q_NAME})
        self.qMetrics.append({'name': 'Queue.OpenInputCount', 'command': 'MQCMD_INQUIRE_Q', 'attr': MQIA_OPEN_INPUT_COUNT, 'owner': 'Queue', 'metric': 'absolute', 'splitName': 'Queue', 'splitBy': MQCA_Q_NAME})
        self.qMetrics.append({'name': 'Queue.OpenOutputCount', 'command': 'MQCMD_INQUIRE_Q', 'attr': MQIA_OPEN_OUTPUT_COUNT, 'owner': 'Queue', 'metric': 'absolute', 'splitName': 'Queue', 'splitBy': MQCA_Q_NAME})
        self.qMetrics.append({'name': 'Queue.OldestMessageAge', 'command': 'MQCMD_INQUIRE_Q_STATUS', 'attr': MQIACF_OLDEST_MSG_AGE, 'owner': 'Queue', 'metric': 'absolute', 'unavailable': MQMON_NOT_AVAILABLE, 'splitName': 'Queue', 'splitBy': MQCA_Q_NAME})
        self.qMetrics.append({'name': 'Queue.UncommittedMessages', 'command': 'MQCMD_INQUIRE_Q_STATUS', 'attr': MQIACF_UNCOMMITTED_MSGS, 'owner': 'Queue', 'metric': 'absolute', 'splitName': 'Queue', 'splitBy': MQCA_Q_NAME})
        self.qMetrics.append({'name': 'Queue.LastGetDate', 'command': 'MQCMD_INQUIRE_Q_STATUS', 'attr': MQCACF_LAST_GET_DATE, 'owner': 'Queue', 'metric': 'absolute', 'splitName': 'Queue', 'splitBy': MQCA_Q_NAME})
        self.qMetrics.append({'name': 'Queue.LastGetTime', 'command': 'MQCMD_INQUIRE_Q_STATUS', 'attr': MQCACF_LAST_GET_TIME, 'owner': 'Queue', 'metric': 'absolute', 'splitName': 'Queue', 'splitBy': MQCA_Q_NAME})
        self.qMetrics.append({'name': 'Queue.LastPutDate', 'command': 'MQCMD_INQUIRE_Q_STATUS', 'attr': MQCACF_LAST_PUT_DATE, 'owner': 'Queue', 'metric': 'absolute', 'splitName': 'Queue', 'splitBy': MQCA_Q_NAME})
        self.qMetrics.append({'name': 'Queue.LastPutTime', 'command': 'MQCMD_INQUIRE_Q_STATUS', 'attr': MQCACF_LAST_PUT_TIME, 'owner': 'Queue', 'metric': 'absolute', 'splitName': 'Queue', 'splitBy': MQCA_Q_NAME})
        if runResetStats == True:
            self.qMetrics.append({'name': 'Queue.DequeueRate', 'command': 'MQCMD_RESET_Q_STATS', 'attr': MQIA_MSG_DEQ_COUNT, 'owner': 'Queue', 'metric': 'absolute', 'splitName': 'Queue', 'splitBy': MQCA_Q_NAME})
            self.qMetrics.append({'name': 'Queue.EnqueueRate', 'command': 'MQCMD_RESET_Q_STATS', 'attr': MQIA_MSG_ENQ_COUNT, 'owner': 'Queue', 'metric': 'absolute', 'splitName': 'Queue', 'splitBy': MQCA_Q_NAME})
        self.qMetrics.append({'name': 'Queue.TimeIndicator', 'command': 'MQCMD_INQUIRE_Q_STATUS', 'attr': MQIACF_Q_TIME_INDICATOR, 'owner': 'Queue', 'metric': 'absolute', 'unavailable': MQMON_NOT_AVAILABLE, 'splitName': 'Queue', 'splitBy': MQCA_Q_NAME})
        
        self.cMetrics.append({'name': 'Channel.Status', 'command': 'MQCMD_INQUIRE_CHANNEL_STATUS', 'attr': MQIACH_CHANNEL_STATUS, 'owner': 'Channel', 'metric': 'absolute', 'normalValue' : MQCHS_RUNNING, 'splitName': 'Channel', 'splitBy': MQCA_Q_NAME})
        self.cMetrics.append({'name': 'Channel.Messages', 'command': 'MQCMD_INQUIRE_CHANNEL_STATUS', 'attr': MQIACH_MSGS, 'owner': 'Channel', 'metric': 'relative', 'splitName': 'Channel', 'splitBy': MQCACH_CHANNEL_NAME, 'aggregationField': 'totalMsgs'})
        self.cMetrics.append({'name': 'Channel.BytesSent2', 'command': 'MQCMD_INQUIRE_CHANNEL_STATUS', 'attr': MQIACH_BYTES_SENT, 'owner': 'Channel', 'metric': 'relative', 'splitName': 'Channel', 'splitBy': MQCACH_CHANNEL_NAME, 'aggregationField': 'totalBytesSent'})
        self.cMetrics.append({'name': 'Channel.BytesReceived2', 'command': 'MQCMD_INQUIRE_CHANNEL_STATUS', 'attr': MQIACH_BYTES_RECEIVED, 'owner': 'Channel', 'metric': 'relative', 'splitName': 'Channel', 'splitBy': MQCACH_CHANNEL_NAME, 'aggregationField': 'totalBytesReceived'})
        self.cMetrics.append({'name': 'Channel.BuffersSent', 'command': 'MQCMD_INQUIRE_CHANNEL_STATUS', 'attr': MQIACH_BUFFERS_SENT, 'owner': 'Channel', 'metric': 'relative', 'splitName': 'Channel', 'splitBy': MQCACH_CHANNEL_NAME, 'aggregationField': 'totalBuffersSent'})
        self.cMetrics.append({'name': 'Channel.BuffersReceived', 'command': 'MQCMD_INQUIRE_CHANNEL_STATUS', 'attr': MQIACH_BUFFERS_RECEIVED, 'owner': 'Channel', 'metric': 'relative', 'splitName': 'Channel', 'splitBy': MQCACH_CHANNEL_NAME, 'aggregationField': 'totalBuffersReceived'})
        self.cMetrics.append({'name': 'Channel.LastMsgDate', 'command': 'MQCMD_INQUIRE_CHANNEL_STATUS', 'attr': MQCACH_LAST_MSG_DATE, 'owner': 'Channel', 'metric': 'absolute', 'splitName': 'Channel', 'splitBy': MQCACH_CHANNEL_NAME})
        self.cMetrics.append({'name': 'Channel.LastMsgTime', 'command': 'MQCMD_INQUIRE_CHANNEL_STATUS', 'attr': MQCACH_LAST_MSG_TIME, 'owner': 'Channel', 'metric': 'absolute', 'splitName': 'Channel', 'splitBy': MQCACH_CHANNEL_NAME})
        self.cMetrics.append({'name': 'Channel.CurrentSharingConvs', 'command': 'MQCMD_INQUIRE_CHANNEL_STATUS', 'attr': MQIACH_CURRENT_SHARING_CONVS, 'owner': 'Channel', 'metric': 'absolute', 'splitName': 'Channel', 'splitBy': MQCACH_CHANNEL_NAME, 'aggregationField': 'totalCurrentSharingConvs'})
        #self.cMetrics.append({'name': 'Channel.Status', 'command': 'MQCMD_INQUIRE_CHANNEL_STATUS', 'attr': MQIACH_CHANNEL_STATUS, 'owner': 'Channel', 'metric': 'absolute', 'splitName': 'Channel', 'splitBy': MQCACH_CHANNEL_NAME})
        
        self.lMetrics.append({'name': 'Channel.ListenerStatus', 'command': 'MQCMD_INQUIRE_LISTENER_STATUS', 'attr': MQIACH_LISTENER_STATUS, 'owner': 'ChannelListener', 'metric': 'absolute', 'splitName': 'Listener', 'splitBy': MQCACH_LISTENER_NAME, 'normalValue': MQSVC_STATUS_RUNNING})
        
        conn_info = ','.join(hostList)
        
        pcf = None
        qmgr = pymqi.QueueManager(None)
        
        try:
            qmgr = self.makeConnection(config, conn_info)
            pcf = pymqi.PCFExecute(qmgr)
        except pymqi.MQMIError as e:
            if e.comp == MQCC_FAILED:
                if qmgr.is_connected:
                    qmgr.disconnect()
                if e.reason == MQRC_HOST_NOT_AVAILABLE:
                    self.setMetric('absolute', 'QueueManager.Status', 0, {})
                    if self.firstExecution:
                        raise ConfigException(f'Could not connect to Queue Manager: {queueManager}. Unknown host {conn_info}')
                    logger.error(f'Connection to {host_port} failed: Setting availability to 0%. {e.errorAsString()}')
                elif e.reason == MQRC_NOT_AUTHORIZED:
                    self.node.report_error_event(f'Connection failed. Unauthorized user. {e.errorAsString()}', 'Unauthorized user')
                    raise AuthException(f'Connection failed. Unauthorized user {config["auth_user"]}. {e.errorAsString()}')
                elif e.reason == MQRC_KEY_REPOSITORY_ERROR:
                    self.node.report_error_event(f'Connection failed. Error in SSL key repository. {e.errorAsString()}', 'Key repository')
                    raise ConfigException(f'Connection failed. Error in SSL key repository {config["key_repo_location"]}. {e.errorAsString()}')
                elif e.reason == MQRC_Q_MGR_NAME_ERROR:
                    self.node.report_error_event(f'Connection failed. Queue manager error: {queueManager}', 'Queue manager error')
                    raise ConfigException(f'Connection failed. Queue manager not found: {queueManager}. {e.errorAsString()}')
                elif e.reason == MQRC_SSL_INITIALIZATION_ERROR:
                    self.node.report_error_event(f'Connection failed. Attempted to initialize SSL connection and failed. {e.errorAsString()}', 'SSL error')
                    raise ConfigException(f'Connection failed. Failed to initialize SSL connection. {e.errorAsString()}')
                else:
                    self.setMetric('absolute', 'QueueManager.Status', 0, {})
                    if self.firstExecution:
                        raise ConfigException(f'Could not connect to Queue Manager: {queueManager} at {conn_info}. {e.errorAsString()}')
                    logger.error(f'Connection to {host_port} failed: Setting availability to 0%. {e.errorAsString()}')
                return
            else:
                if e.reason == MQRC_SELECTOR_NOT_FOR_TYPE:
                    logger.warn(f'Attempting to collect data for a queue type not supported. {e.errorAsString()}')
                elif e.reason == MQRC_SSL_ALREADY_INITIALIZED:
                    logger.warn(f'SSL already connected to {conn_info}, using previous connection. {e.errorAsString()}. Continuing')
                else:
                    logger.warn(f'An issue occurred connecting to {conn_info}. {e.errorAsString()}. Continuing')
        except Exception as e:
            logger.error(f'An unknown error occurred. {e}')

        if isinstance(pcf, pymqi.PCFExecute) and qmgr and qmgr.is_connected:
            self.queue_manager = queueManager
            
            try:
                # Query for topology
                if config['get_queue_topology'] and (self.firstExecution or time.time()-self.last_topology_retrieve[queueManager]['time'] > 3600):
                    topology_data = self.build_topology(pcf, qmgr)
                    
                    if topology_data:
                        result = self.send_topology(topology_data, config['api_token'], config['api_endpoint'])
            except pymqi.MQMIError as e:
                logger.exception(f'Could not query queue manager topology. Reason: {e.errorAsString()}')
                self.report_custom_info_event(f'Could not query queue manager {queueManager} topology. Reason: {e.errorAsString()}', 'Could not query queue manager')
                
            # Let's start by pinging the Queue Manager. If anything but an empty response, then it's unresponsive and no point continuing
            pingResponse = False
            try:
                pcf.MQCMD_PING_Q_MGR()
            except pymqi.MQMIError as e:
                # Not necessarily unresponsive. If it's on z/OS the command does not exist so we skip that error
                if e.comp == MQCC_WARNING and e.reason == MQRC_SELECTOR_NOT_FOR_TYPE:
                    logger.warn('PING_Q_MGR command not supported on this platform, stopping...')
                    raise ConfigException(f'Could not run ping command to {queueManager} due to unsupported OS. Supported platforms are Windows/Linux/AIX')
                    return
                else: 
                    self.report_custom_info_event(f'Ping to queue manager {queueManager} failed. Queue manager may be unresponsive.', f'Ping to {queueManager} failed')
                    logger.warn('Ping command failed. Attemping to continue polling data.')
                    #return

            qResponse, cResponse, lResponse = {}, {}, {}
            totalActiveChannels = None
            
            # If it's been over an hour since last retrieval or failed or skipped entities, reset to retry them
            now = time.time()
            if now - self.timeSinceLastRetrieve > 3600:
                self.refreshItemNames = True
                self.timeSinceLastRetrieve = now
                
            qmgrResponse = {}
            
            try:
                logger.debug(f'Inquiring Version from Q_MGR {queueManager}')
                qmgrVersionRes = getattr(pcf, 'MQCMD_INQUIRE_Q_MGR')({MQIACF_Q_MGR_ATTRS: MQCA_VERSION})[0]
                version = qmgrVersionRes[MQCA_VERSION].strip()
                version = f'{int(version[0:2])}.{int(version[2:4])}'
            except pymqi.MQMIError as e:
                logger.warn(f'Could not get version. {e.errorAsString()}')
                version = 'Unknown version'
                
            try:
                logger.debug('Inquiring platform from Q_MGR '+queueManager)
                platform = qmgr.inquire(MQIA_PLATFORM)
                if platform not in [3,5,11,28]:
                    if platform not in self.OS:
                        self.OS[platform] = f'Unknown[{platform}]'
                    raise ConfigException(f'Unsupported MQ platform: {self.OS[platform]}. Supported platforms are Windows/Linux/AIX')
                    return
                    
                maxPriority = qmgr.inquire(MQIA_MAX_PRIORITY)
                
                if platform in self.OS:
                    OSname = f'IBM MQ {version} on {self.OS[platform]}'
                else:
                    OSname = f'Unknown[{platform}]'
                    
                self.node.report_property('Version', OSname)
                self.node.report_property('Max Priority', str(maxPriority))
                
                logger.debug('Running Q_MGR commands')
                for command in qmgrCommands:
                    # Run command with its arguments
                    qmgrResponse = getattr(pcf, command)()[0]
                    #logger.info(qmgrResponse)
                    
                if dlq_alert:
                    # Get the Dead Letter queue name
                    # Report a problem if DLQ has messages. These are undeliverable messages.
                    logger.debug(f'dlq_alert = {dlq_alert}')
                    logger.debug(f'Inquiring Q_MGR {queueManager} for DLQ')
                    deadLetterQName = str(qmgr.inquire(MQCA_DEAD_LETTER_Q_NAME), 'utf-8', 'ignore').strip()
                    deadLetterQDepth = None                  
                    try:
                        if deadLetterQName != '':
                            logger.debug(f'DLQ is {deadLetterQName}')
                            deadLetterQ = pymqi.Queue(qmgr, deadLetterQName)
                            deadLetterQDepth = deadLetterQ.inquire(MQIA_CURRENT_Q_DEPTH)
                            if deadLetterQDepth > 0:
                                self.node.report_error_event(f'Dead letter queue {deadLetterQName} on {queueManager} has {deadLetterQDepth} undeliverable message(s)', f'DLQ {deadLetterQName} on {queueManager} has message(s)')
                    except pymqi.MQMIError as e2:
                        self.report_custom_info_event(f'Could not collect data from Dead letter queue {deadLetterQName} on {queueManager}. {e2.errorAsString()}', 'Error collecting from DLQ')
                        logger.warn(f'WARNING: Attempted to get data from DLQ {deadLetterQName} but failed. {e2.errorAsString()}')
                    finally:        
                        if deadLetterQDepth:               
                            deadLetterQ.close()
                
                try:
                    # Get a count of active channels
                    logger.debug(f'Inquiring Q_MGR {queueManager} for total current active channels')
                    args = {MQCACH_CHANNEL_NAME: pymqi.ensure_bytes('*'), MQIACH_CHANNEL_INSTANCE_ATTRS: MQCACH_CHANNEL_NAME, MQIACH_CHANNEL_INSTANCE_TYPE: MQOT_CURRENT_CHANNEL}
                    currentChannelsResponse = getattr(pcf, 'MQCMD_INQUIRE_CHANNEL_STATUS')(args)
                    totalActiveChannels = len(currentChannelsResponse)
                except pymqi.MQMIError as e2:
                    totalActiveChannels = 0
                    logger.warn(f'Could not get total active channels on {OSname} for {queueManager}... Continuing. {e2.errorAsString()}')
                    
                # Get queue names and count first so we can multi-thread them. If we don't, we may get too many results and plugin may time out
                logger.debug(f'Inquire Q_MGR {queueManager}for Q names and Channel names')
                if self.refreshItemNames:
                    self.qItems = self.getItemNames(pcf, queueManager, queues, 'MQCMD_INQUIRE_Q_NAMES', MQCA_Q_NAME, MQCACF_Q_NAMES, excludeSystem)
                    self.cItems = self.getItemNames(pcf, queueManager, channels, 'MQCMD_INQUIRE_CHANNEL_NAMES', MQCACH_CHANNEL_NAME, MQCACH_CHANNEL_NAMES, excludeSystem)
                    self.refreshItemNames = False
                    
                # Query MQ for listener status
                logger.debug(f'Inquiring {queueManager} Listener for with commands: {listenerCommands}')
                self.getMetricsForEntity(pcf, queueManager, listeners, listenerCommands, MQCACH_LISTENER_NAME, lResponse)
                
            except pymqi.MQMIError as e:
                if e.comp == MQCC_WARNING and e.reason == MQRC_SELECTOR_NOT_FOR_TYPE:
                    logger.warn('Could not run some commands on this OS, perhaps it is not supported. Continuing...')
                else:
                    logger.exception(f'Could not query queue manager. Reason: {e.errorAsString()}')
                    self.report_custom_info_event(f'Could not query queue manager {queueManager}. Reason: {e.errorAsString()}', 'Could not query queue manager')
            finally:
                if qmgr.is_connected:
                    qmgr.disconnect()
            
            qItemsCount = len(self.qItems)
            logger.info(f'qItems: {self.qItems}')
            logger.info(f'cItems: {self.cItems}')

            # Number of threads that will be created for each batch
            qThreads = math.ceil(qItemsCount / self.maxBatchItems)
            cThreads = math.ceil(len(self.cItems) / self.maxBatchItems)
            poolSize = qThreads + cThreads
            
            if poolSize > 0:
                # Run queue threads
                pool = ThreadPool(processes=poolSize)
                startList = 0
                for count in range(qThreads):
                    endList = startList + self.maxBatchItems
                    pool.apply_async(self.getThreadedMetricsForEntity, (config, conn_info, self.qItems[startList:endList], qCommands, MQCA_Q_NAME, qResponse))
                    startList = endList
                    logger.debug(f'Started queue thread number {count}')
                    
                # Run channel threads
                startList = 0
                for count in range(cThreads):
                    endList = startList + self.maxBatchItems
                    pool.apply_async(self.getThreadedMetricsForEntity, (config, conn_info, self.cItems[startList:endList], channelCommands, MQCACH_CHANNEL_NAME, cResponse))
                    startList = endList
                    logger.debug(f'Started channel thread number {count}')
                pool.close()
                
                # Max polling time is 50 seconds
                process_alive = False
                while time.time() - self.start < 50:
                    process_alive = False
                    for process in pool._pool:
                        if process.is_alive():
                            process_alive = True
                   
                    if not process_alive:
                        logger.info('All processes finished, exiting checking loop')
                        break
                        
                    logger.info(f'Sleeping for a second... process is still alive')
                    time.sleep(1)
                
                # If we get to this point, a process was flagged alive and it's been more than 50 seconds, then terminate it
                # Otherwise, if process_alive was not set above, then no process should be alive at this point and no need to terminate
                if process_alive:
                    pool.terminate()
                    pool.join()
                    logger.info('Some processes are alive. Terminating before finishing polling cycle')
                
            # Loop through Queue Manager metrics result
            logger.info(f'Reporting metrics for Queue Manager. QM Metrics: {len(self.qmgrMetrics)}')
            for metric in self.qmgrMetrics:
                fieldId = metric['attr']
                metricDimension = {}
                if metric['owner'] == 'QueueManager':
                    if fieldId in qmgrResponse:
                        logger.debug(f'qMgr: {metric["attr"]}: {qmgrResponse[fieldId]}')
                        val = qmgrResponse[fieldId]
                        if 'normalValue' in metric:
                            val = 100 if val == metric['normalValue'] else 0
                        self.setMetric(metric['metric'], metric['name'], val, {})
            if totalActiveChannels:
                self.setMetric('absolute', 'QueueManager.ActiveChannels', totalActiveChannels, {})

            # Loop through all Queue metrics results
            logger.info(f'Reporting metrics for Queues. Queue Metrics: {len(qResponse)}')
            for queue in qResponse:
                metricDimension = {}
                metricDimension['Queue'] = queue
                maxQueueDepth, currentQueueDepth, lastGetDate, lastGetTime, lastPutDate, lastPutTime = None,None,None,None,None,None
                
                for command in qResponse[queue]:
                    for metric in self.qMetrics:
                        fieldId = metric['attr']
                        if command == metric['command']:
                            if fieldId in qResponse[queue][command]:
                                if metric['attr'] == MQIACF_Q_TIME_INDICATOR:
                                    if len(qResponse[queue][command][fieldId]) > 0:
                                        qTimeShort = qResponse[queue][command][fieldId][0]
                                        qTimeLong = qResponse[queue][command][fieldId][1]
                                        if qTimeShort != MQMON_NOT_AVAILABLE and qTimeLong != MQMON_NOT_AVAILABLE:
                                            self.setMetric(metric['metric'], metric['name']+'Short', qTimeShort, metricDimension)
                                            self.setMetric(metric['metric'], metric['name']+'Long', qTimeLong, metricDimension)
                                elif metric['attr'] == MQCACF_LAST_GET_DATE:
                                    if len(qResponse[queue][command][fieldId]) > 0:
                                        lastGetDate = datetime.strptime(qResponse[queue][command][fieldId], '%Y-%m-%d')
                                elif metric['attr'] == MQCACF_LAST_GET_TIME:
                                    if len(qResponse[queue][command][fieldId]) > 0:
                                        lastGetTime = datetime.strptime(qResponse[queue][command][fieldId], '%H.%M.%S')
                                elif metric['attr'] == MQCACF_LAST_PUT_DATE:
                                    if len(qResponse[queue][command][fieldId]) > 0:
                                        lastPutDate = datetime.strptime(qResponse[queue][command][fieldId], '%Y-%m-%d')
                                elif metric['attr'] == MQCACF_LAST_PUT_TIME:
                                    if len(qResponse[queue][command][fieldId]) > 0:
                                        lastPutTime = datetime.strptime(qResponse[queue][command][fieldId], '%H.%M.%S')
                                elif metric['attr'] == MQIA_MSG_DEQ_COUNT or metric['attr'] == MQIA_MSG_ENQ_COUNT:
                                    if MQIA_TIME_SINCE_RESET in qResponse[queue][command]:
                                        if qResponse[queue][command][MQIA_TIME_SINCE_RESET] == 0:
                                            qResponse[queue][command][MQIA_TIME_SINCE_RESET] = 1
                                        self.setMetric(metric['metric'], metric['name'], int(qResponse[queue][command][fieldId])/float(qResponse[queue][command][MQIA_TIME_SINCE_RESET]), metricDimension)
                                else:
                                    if metric['attr'] == MQIA_MAX_Q_DEPTH:
                                        maxQueueDepth = qResponse[queue][command][fieldId]
                                    if metric['attr'] == MQIA_CURRENT_Q_DEPTH:
                                        currentQueueDepth = qResponse[queue][command][fieldId]
                                    if metric['attr'] != MQIA_MAX_Q_DEPTH:
                                        self.setMetric(metric['metric'], metric['name'], qResponse[queue][command][fieldId], metricDimension)

                    '''
                    # Check Inhibit Put/Get
                    if command == 'MQCMD_INQUIRE_Q' and (MQIA_INHIBIT_GET in qResponse[queue][command] and MQIA_INHIBIT_PUT in qResponse[queue][command]):
                        if int(qResponse[queue][command][MQIA_INHIBIT_GET]) == 1:
                            self.node.report_availability_event(f'Queue {queue} on queue manager {self.queue_manager} is inhibiting MQGET', f'Queue {queue} is inhibiting GET')
                            logger.warn(f'Queue {queue} on queue manager {self.queue_manager} is inhibiting MQGET')
                        if int(qResponse[queue][command][MQIA_INHIBIT_PUT]) == 1:
                            self.node.report_availability_event(f'Queue {queue} on queue manager {self.queue_manager} is inhibiting MQPUT', f'Queue {queue} is inhibiting PUT')
                            logger.warn(f'Queue {queue} on queue manager {self.queue_manager} is inhibiting MQPUT')
                    '''        
                if maxQueueDepth and currentQueueDepth is not None:
                    queuePercentQueueDepth = (currentQueueDepth * 100) / maxQueueDepth if maxQueueDepth > 0 else 0
                    self.setMetric(metric['metric'], 'Queue.PercentQueueDepth', queuePercentQueueDepth, metricDimension)
                
                if lastGetDate and lastGetTime:
                    lastGetDateTimeDelta = datetime.now()-datetime.combine(lastGetDate.date(), lastGetTime.time())
                    logger.debug(f'lastGetDateTimeDelta: {lastGetDateTimeDelta}')
                    lastGetDateTime = (lastGetDateTimeDelta.seconds*1000)+(lastGetDateTimeDelta.microseconds/1000)
                    self.setMetric('absolute', 'Queue.LastGet', lastGetDateTime, metricDimension)
                
                if lastPutDate and lastPutTime:
                    lastPutDateTimeDelta = datetime.now()-datetime.combine(lastPutDate.date(), lastPutTime.time())
                    logger.debug(f'lastPutDateTimeDelta: {lastPutDateTimeDelta}')
                    lastPutDateTime = (lastPutDateTimeDelta.seconds*1000)+(lastPutDateTimeDelta.microseconds/1000)
                    self.setMetric('absolute', 'Queue.LastPut', lastPutDateTime, metricDimension)
                    
            # Loop through all Channel metrics results
            logger.info(f'Reporting metrics for channels. Channel Metrics: {len(cResponse)}')
            for channel in cResponse:
                metricDimension = {}
                for metric in self.cMetrics:
                    metricDimension[metric['splitName']] = channel
                    fieldId = metric['attr']
                    for command in cResponse[channel]:
                        if command == metric['command']:
                            if fieldId in cResponse[channel][command] and str(cResponse[channel][command][fieldId]).strip() != '':
                                val = cResponse[channel][command][fieldId]
                                if metric['attr'] == MQIACH_CHANNEL_STATUS:
                                    if val == MQCHS_RETRYING and retry_channel_alert:
                                        self.node.report_error_event_event(f'Channel {channel} on {queueManager} is in Retrying state', f'Channel {channel} in Retrying state', properties={'Queue manager': queueManager, 'Channel': channel, 'Host': host_port})
                                    self.node.state_metric('Channel.Substatus', self.channel_states[val], metricDimension)
                                if 'normalValue' in metric:
                                    val = 100 if val == metric['normalValue'] else 0
                                elif 'aggregationField' in metric:
                                    if metric['aggregationField'] in cResponse[channel]:
                                        val = cResponse[channel][metric['aggregationField']]
                                if metric['attr'] == MQCACH_LAST_MSG_DATE:
                                    df = '%Y-%m-%d'
                                    lastMsgDate = datetime.strptime(val, df)
                                elif metric['attr'] == MQCACH_LAST_MSG_TIME:
                                    tf = '%H.%M.%S'
                                    lastMsgTime = datetime.strptime(val, tf)
                                else:
                                    self.setMetric(metric['metric'], metric['name'], val, metricDimension)

                # Last messages needs to be converted to seconds as it is an array object of dates
                if 'lastMsg' in cResponse[channel]:
                    lastMsgDateTime = (datetime.now()-cResponse[channel]['lastMsg']).total_seconds()
                    self.setMetric('absolute', 'Channel.LastMsg', lastMsgDateTime, metricDimension)

            # Loop through all Listener metrics
            logger.info(f'Reporting metrics for Listeners. Listener Metrics: {len(lResponse)}')
            for listener in lResponse:
                metricDimension = {}
                for metric in self.lMetrics:
                    metricDimension[metric['splitName']] = listener
                    fieldId = metric['attr']
                    for command in lResponse[listener]:
                        if command == metric['command']:
                            if fieldId in lResponse[listener][command]:
                                val = lResponse[listener][command][fieldId]
                                if 'normalValue' in metric:
                                    val = 100 if val == metric['normalValue'] else 0
                                self.setMetric(metric['metric'], metric['name'], val, metricDimension)
                                
            cResponse.clear()
            qResponse.clear()
            lResponse.clear()
            qmgrResponse.clear()
        else:
            logger.warn(f'Not able to get pcf connection object. Finishing...')
        # After executing once
        self.firstExecution = False      
        
        if qmgr:
            if qmgr.is_connected:
                qmgr.disconnect()
                qmgr = None
                
        logger.info(f'Finished executing plugin.')

    # Get list of item names first to get an idea how many will be returned when we actually get data
    def getItemNames(self, pcf, queueManager, entities, command, identifier, returnedIdentifier, excludeSystem):
        items, exclusions, inclusions = [],[],[]
        searchingQueues = False
        ran_once = False
        for entity in entities:
            if entity.startswith('-') or entity.startswith('~'):
                exclusions.append(entity[1:])
            else:
                if '*' not in entity:
                    logger.debug(f'Added entity to inclusion: {entity}')
                    inclusions.append(entity)
                    items.append(entity)
                    continue
                else:
                    inclusions.append(entity)
                    if not ran_once: # Only search for * once
                        args = {identifier : pymqi.ensure_bytes('*')}
                        logger.debug(f'Searching for: * using command {command} then filtering after')
                        try:
                            fullResponse = getattr(pcf, command)(args)
                            #logger.debug(f'FullResponse: {fullResponse} from command {command}')
                            for eachEntity in fullResponse:
                                if returnedIdentifier in eachEntity: # Make sure it's not an empty result
                                    itemNames = eachEntity[returnedIdentifier]
                                    if (MQIACF_Q_TYPES in eachEntity):
                                        searchingQueues = True
                                    logger.debug(f'Total items: {len(itemNames)}')
                                    
                                    # Add only items that are not in list
                                    if isinstance(itemNames, list):
                                        for index, name in enumerate(itemNames):
                                            name = str(name,'utf-8', 'ignore').strip()
                                            if (searchingQueues and name not in items and eachEntity[MQIACF_Q_TYPES][index] == MQQT_LOCAL) or (not searchingQueues and name not in items):
                                                items.append(name)
                                    else:
                                        itemNames = str(itemNames,'utf-8', 'ignore').strip()
                                        if (searchingQueues and itemNames not in items and eachEntity[MQIACF_Q_TYPES] == MQQT_LOCAL) or (not searchingQueues and itemNames not in items):
                                            items.append(itemNames)
                                
                        except pymqi.MQMIError as e:
                            if e.comp == MQCC_FAILED and e.reason == MQRC_UNKNOWN_OBJECT_NAME:
                                self.report_custom_info_event(f'Error collecting information for {entity} on {queueManager}. Not found or wrong type. {e.errorAsString()}', f'{entity} on {queueManager}. Not found or wrong type')
                                logger.error(f'Error collecting information for {entity} on {queueManager}. {e.errorAsString()}')
                                #raise ConfigException('Error collecting information for ' + entity + '. Not found or wrong type')
                            else:
                                logger.error(f'Error searching for {entity} on {queueManager}. {e.errorAsString()}')
                            continue
                        ran_once = True
        
        # Filter out any SYSTEM items if selected
        if excludeSystem == True:
            exclusions.append('SYSTEM.*')
        
        # Run filters on the results and join remaining results
        itemsIncluded = list(self.filterItems(items, inclusions, False))
        itemsToExclude = list(self.filterItems(items, exclusions, False))
        
        items = [i for i in itemsIncluded if i and i not in itemsToExclude]
        # Still limit the results to MAX_RESULTS
        return items[0:MAX_RESULTS]
    
    def filterItems(self, items, patterns, exclude):
        if exclude:
            #logger.info(f'Excluding items that match pattern in {patterns}')
            for item in items:
                if any(fnmatch.fnmatch(item, pattern) for pattern in patterns):
                    #logger.info(f'item {item} matches exclusion in {patterns}. Marked for removal')
                    yield item
        else:
            #logger.info(f'Including items that match pattern in {patterns}')
            for item in items:
                if any(fnmatch.fnmatch(item, pattern) for pattern in patterns):
                    #logger.info(f'item {item} matches pattern in {patterns}')
                    yield item
                
    # Collect metrics for each entity and command
    def getMetricsForEntity(self, pcf, queueManager, entities, commands, identifier, metricResponse):
        args = {}
        currentIteration = 0
        for entity in entities:
            qType = {}
            for command in commands:
                logger.debug(f'Doing command {command} for entity {entity}')
                timerStart = time.time()
                if (identifier):
                    logger.debug(f'Identifier: {identifier}')
                    args = {identifier : pymqi.ensure_bytes(entity)}
                    #if command == 'MQCMD_INQUIRE_CHANNEL_STATUS':
                        #args[MQIACH_CHANNEL_INSTANCE_TYPE] = MQOT_SAVED_CHANNEL
                try:
                    fullResponse = getattr(pcf, command)(args)
                    #logger.debug(f'FullResponse from command {command} on {entity}: {fullResponse}')
                    logger.debug(f'Received response from MQ. Command: {command}. Entity: {entity}. Took {time.time()-timerStart} seconds')

                    for i, eachEntity in enumerate(fullResponse):
                        #Clean each key-value pair. Data from MQ comes with extra spaces
                        eachEntity = { k:str(v,'utf-8', 'ignore').strip() if isinstance(v, bytes) else v for k,v in eachEntity.items() }
                        #eachEntity = { k:v.strip() if isinstance(v, str) else v for k,v in eachEntity.items() }
                        entityName = eachEntity[identifier]
                        if entityName not in metricResponse:
                            metricResponse[entityName] = {}
                        
                        metricResponse[entityName][command] = eachEntity
                        #logger.info(f'eachEntity = {eachEntity}')
                            
                        # Add metrics for multi-channel instances
                        # Keep track of the previous number and add it to a new metric grouped by the entity
                        # This also takes care of initialization issues of the new metric if it does not exist and adds to it if it exists
                        if command == 'MQCMD_INQUIRE_CHANNEL_STATUS':
                            if MQCACH_LAST_MSG_DATE in eachEntity:
                                lastMsgDate = datetime.strptime(eachEntity[MQCACH_LAST_MSG_DATE], '%Y-%m-%d') if eachEntity[MQCACH_LAST_MSG_DATE] != '' else None
                                lastMsgTime = datetime.strptime(eachEntity[MQCACH_LAST_MSG_TIME], '%H.%M.%S') if eachEntity[MQCACH_LAST_MSG_TIME] != '' else None
                                if isinstance(lastMsgDate, datetime) and isinstance(lastMsgTime, datetime):
                                    lastMsgDateTime = datetime.combine(lastMsgDate.date(), lastMsgTime.time())
                                    
                                    if ('lastMsg' not in metricResponse[entity]) or ('lastMsg' in metricResponse[entity] and metricResponse[entity]['lastMsg'] < lastMsgDateTime):
                                        metricResponse[entity]['lastMsg'] = lastMsgDateTime
                            for metric in self.cMetrics:
                                if 'aggregationField' in metric and metric['attr'] in eachEntity:
                                    metricResponse[entityName][metric["aggregationField"]] = metricResponse[entityName][metric["aggregationField"]]+float(eachEntity[metric["attr"]]) if metric["aggregationField"] in metricResponse[entityName] else float(eachEntity[metric["attr"]])
                        #if command == 'MQCMD_INQUIRE_Q':
                        #    qType[entityName] = eachEntity[MQIA_Q_TYPE]
                        logger.debug(f'Did command {command} for entity {entityName}[{i}]. Size: {len(eachEntity)}')
                        currentIteration += 1
                        
                        # If the current iteration from any entity reached max MAX_RESULTS, stop and return
                        # This is to avoid bringing back too many when using wildcards
                        if currentIteration == MAX_RESULTS:
                            break
                except pymqi.MQMIError as e:
                    if e.comp == MQCC_WARNING and e.reason == MQRC_SELECTOR_NOT_FOR_TYPE:
                        logger.warn(f'{command} command not supported on this OS. Continuing...')
                    elif e.comp == MQCC_FAILED and e.reason == MQRCCF_CHL_STATUS_NOT_FOUND:
                        self.setMetric('absolute', 'Channel.Status', 0, {'Channel': entity})
                        self.report_custom_info_event(f'Channel {entity} on {queueManager} is unavailable or not active. {e.errorAsString()}', f'Channel {entity} not active')
                        #logger.warning(f'Channel status for {entity} on {queueManager} not found.')
                    elif e.comp == MQCC_FAILED and e.reason == MQRC_UNKNOWN_OBJECT_NAME:
                        self.report_custom_info_event(f'Error collecting information for {entity} on {queueManager}, not found. {e.errorAsString()}', f'{entity} on {queueManager}, not found')
                        logger.warning(f'Error collecting information for {entity} on {queueManager}. {e.errorAsString()}')
                    else:
                        logger.error(f'Error occurred collecting data for {entity} on {queueManager}. {e.errorAsString()}')
                    continue

        #logger.info('------ Response: ' + str(metricResponse) + ' for entities ' + str(entities) + ' using command ' + str(commands))
    
    # Collect metrics for each entity and command
    def getThreadedMetricsForEntity(self, config, conn_info, entities, commands, identifier, metricResponse):
        try:
            newQmgr = self.makeConnection(config, conn_info)
            newPcf = pymqi.PCFExecute(newQmgr)
            
            logger.debug('Created new QM connection for thread')
            self.getMetricsForEntity(newPcf, config['queue_manager'].strip(), entities, commands, identifier, metricResponse)
        
        except pymqi.MQMIError as e:
            logger.exception(f'Could not gather threaded metrics for entities: {e.errorAsString()}')        
        except Exception as e:
            logger.exception(f'Exception getting threaded metrics: {e}')
        finally:
            if newQmgr and newQmgr.is_connected:
                newQmgr.disconnect()
                newQmgr = None
                logger.debug(f'Disconnected from MQ[Identifier: {identifier}]')
            #logger.info('------ Response: ' + str(metricResponse) + ' for entities ' + str(entities) + ' using command ' + str(commands))
        
    def makeConnection(self, config, conn_info):
        queueManager = config['queue_manager'].strip()
        
        logger.debug(f'conn_info: {conn_info} with shared connection')
        # Create Connector Descriptor to MQ 
        cd = pymqi.CD()
        cd.ChannelName = pymqi.ensure_bytes(config['server_connection'].strip())
        cd.ConnectionName = pymqi.ensure_bytes(conn_info)
        cd.ChannelType = MQCHT_CLNTCONN
        cd.TransportType = MQXPT_TCP
        
        connect_options = MQCNO_HANDLE_SHARE_BLOCK
        
        qmgr = pymqi.QueueManager(None)
        try:
            if config['key_repo_location'] != '':
                logger.debug('key_repo_location is set so make threaded connection with SSL')
                cd.SSLCipherSpec = pymqi.ensure_bytes(config['cipher_spec'].strip())
                sco = pymqi.SCO()
                sco.KeyRepository = pymqi.ensure_bytes(config['key_repo_location'].strip())
                if (config['auth_user'] != ''):
                    qmgr.connect_with_options(queueManager, cd, sco, user=config['auth_user'], password=config['auth_password'], opts=connect_options)
                else:
                    qmgr.connect_with_options(queueManager, cd, sco, opts=connect_options)
            else: # Otherwise just connect without SSL
                if (config['auth_user'] != ''):
                    qmgr.connect_with_options(queueManager, cd, user=config['auth_user'], password=config['auth_password'], opts=connect_options)
                else:
                    qmgr.connect_with_options(queueManager, cd, opts=connect_options)
            return qmgr
        except pymqi.MQMIError as e:
            raise e
        
    # Set metric according to metric type: absolute or relative
    def setMetric(self, metricType, keyName, val, metricDimension):
        if (metricType == 'absolute'):
            self.node.absolute(key=keyName, value=val, dimensions=metricDimension)
        else:
            key = self.queue_manager+'_'+list(metricDimension.values())[0]+'_'+keyName
            if key not in self.metricHolder:
                self.metricHolder[key] = val
            else:
                deltaVal = abs(self.metricHolder[key]-val)
                self.metricHolder[key] = val
                logger.debug(f'Setting Delta: {key} = {deltaVal} for dimension {metricDimension}')
                self.node.absolute(key=keyName, value=deltaVal, dimensions=metricDimension)
                
    def report_custom_info_event(self, message, title, properties={}):
        if self.events < MAX_EVENTS:
            if title + message not in self.previousEvents:
                self.events += 1
                self.node.report_custom_info_event(message, title, properties)
                self.previousEvents.append(title + message)
                
    def build_topology(self, pcf, qmgr):
        cluster_data = {}
        clusterNameList, qNameList = None, None
        jsonified = None
        nameListResponse = None

        
        cluster_data['name'] = self.queue_manager
        cluster_data['clusters'] = []
        logger.info('Inquiring cluster names')
        
        try: 
            # Get non-repository clusters
            args = {pymqi.CMQC.MQCA_CLUSTER_Q_MGR_NAME : pymqi.ensure_bytes(self.queue_manager), 
                    MQIACF_CLUSTER_Q_MGR_ATTRS: pymqi.CMQC.MQCA_CLUSTER_NAME}
            clusterResponse = pcf.MQCMD_INQUIRE_CLUSTER_Q_MGR(args)
            #logger.info(f'ClusterResponse: {clusterResponse}')
            for each in clusterResponse:
                if MQCA_CLUSTER_NAME in each:
                    if isinstance(each[MQCA_CLUSTER_NAME],list):
                        for x in each[MQCA_CLUSTER_NAME]:
                            cluster_data['clusters'].append(x.strip())
                    else:
                        cluster_data['clusters'].append(each[MQCA_CLUSTER_NAME].strip())
        except pymqi.MQMIError as e:
            logger.error(f'Could not inquire cluster names from queue manager {self.queue_manager}. {e.errorAsString()}')
            self.report_custom_info_event(f'Could not get cluster names from queue manager {self.queue_manager}.', 'Error collecting topology from MQ', properties={'Queue manager': self.queue_manager, 'Error': e.errorAsString()})
            
        # Get repository clusters
        cluster = str(qmgr.inquire(MQCA_REPOSITORY_NAME), 'utf-8', 'ignore').strip()
        clusterNameList = str(qmgr.inquire(MQCA_REPOSITORY_NAMELIST), 'utf-8', 'ignore').strip()

        if clusterNameList != '' and not clusterNameList.strip().startswith('SYSTEM.'):
            logger.info(f'Getting clusters for namelist: {clusterNameList}')
            #args = {pymqi.CMQC.MQCA_NAMELIST_NAME : b'*'}
            args = {pymqi.CMQC.MQCA_NAMELIST_NAME : pymqi.ensure_bytes(clusterNameList)}
            try:
                nameListResponse = pcf.MQCMD_INQUIRE_NAMELIST(args)
                for each in nameListResponse:
                    #cluster_data['clusters'] = [x.strip() for x in nameListResponse[0][MQCA_NAMES]]
                    if MQCA_NAMES in each:
                        if isinstance(each[MQCA_NAMES], list):
                            for x in each[MQCA_NAMES]:
                                cluster_data['clusters'].append(x.strip())
                        else:
                            cluster_data['clusters'].append(each[MQCA_NAMES].strip())
            except pymqi.MQMIError as e:
                logger.error(f'Error getting clusters in namelist {clusterNameList} for {self.queue_manager}. {e.errorAsString()}')
                self.report_custom_info_event(f'Could not get clusters for namelist {str(clusterNameList, "utf-8", "ignore")} in {self.queue_manager}.', 'Error getting clusters from MQ', properties={'Queue manager': self.queue_manager, 'Error': e.errorAsString()})
            
            # In case there are duplicates
            logger.info(f"Added clusters from namelist: {list( dict.fromkeys(cluster_data['clusters']) )}")
            cluster_data['clusters'] = list( dict.fromkeys(cluster_data['clusters']) )
        elif cluster != '' and not cluster.strip().startswith('SYSTEM.'):
            cluster_data['clusters'].append(cluster)
            
        # Retrieve Alias Queue information
        logger.info('Getting alias queues')
        cluster_data['aliasQueues'] = []
        try:
            args = {pymqi.CMQC.MQCA_Q_NAME : b'*',
                    pymqi.CMQC.MQIA_Q_TYPE : pymqi.CMQC.MQQT_ALIAS}
                    
            aliasQResponse = pcf.MQCMD_INQUIRE_Q(args)

            for aliasQ in aliasQResponse:
                if not aliasQ[MQCA_Q_NAME].startswith(b'SYSTEM.') and not aliasQ[MQCA_Q_NAME].startswith(b'MQSERIES.TEMPLATE.'):
                    if not aliasQ[MQCA_Q_NAME].strip() == b'' and not aliasQ[MQCA_BASE_Q_NAME].strip() == b'':
                        cluster = aliasQ[MQCA_CLUSTER_NAME].strip()
                        clusterNameList = aliasQ[MQCA_CLUSTER_NAMELIST].strip()
                        aliasQClusters = []
                        if cluster != b'':
                            aliasQClusters = [cluster]
                        elif clusterNameList != b'':
                            logger.info(f'Getting cluster names for namelist {clusterNameList} from aliasQueue {aliasQ[MQCA_Q_NAME]}')
                            args = {pymqi.CMQC.MQCA_NAMELIST_NAME : pymqi.ensure_bytes(clusterNameList)}
                            try:
                                nameListResponse = pcf.MQCMD_INQUIRE_NAMELIST(args)
                                #aliasQClusters = [x.strip() for x in nameListResponse[0][MQCA_NAMES]]
                                logger.info(f'nameListResponse: {nameListResponse}')
                                for each in nameListResponse:
                                    if MQCA_NAMES in each:
                                        if isinstance(each[MQCA_NAMES], list):
                                            for x in each[MQCA_NAMES]:
                                                aliasQClusters.append(x.strip())
                                        else:
                                            aliasQClusters.append(each[MQCA_NAMES].strip())
                            except pymqi.MQMIError as e:
                                logger.error(f'Error getting aliasQ clusters in namelist {str(clusterNameList, "utf-8", "ignore")} for {self.queue_manager}. {e.errorAsString()}')
                                self.report_custom_info_event(f'Could not get clusters for namelist {str(clusterNameList, "utf-8", "ignore")} in {self.queue_manager}.', 'Error getting clusters from MQ', properties={'Queue manager': self.queue_manager, 'Error': e.errorAsString()})
                            # In case there are duplicates
                            aliasQClusters = list( dict.fromkeys(aliasQClusters) )
                        if aliasQ[MQCA_Q_NAME].strip().upper() != aliasQ[MQCA_BASE_Q_NAME].strip().upper():
                            cluster_data['aliasQueues'].append({'aliasQueue': aliasQ[MQCA_Q_NAME].strip(), 'baseQueue': aliasQ[MQCA_BASE_Q_NAME].strip(), 'clusterVisibility': aliasQClusters})
        except pymqi.MQMIError as e:
            logger.error(f'Error getting alias queues for {self.queue_manager}. {e.errorAsString()}')
            self.report_custom_info_event(f'Could not get alias queues in {self.queue_manager}.', 'Error getting alias queues from MQ', properties={'Queue manager': self.queue_manager, 'Error': e.errorAsString()})
        
        # Retrieve Remote queue information
        logger.info('Getting remote queues')
        cluster_data['remoteQueues'] = []
        try:
            args = {pymqi.CMQC.MQCA_Q_NAME : b'*',
                    pymqi.CMQC.MQIA_Q_TYPE : pymqi.CMQC.MQQT_REMOTE}
                    
            remoteQResponse = pcf.MQCMD_INQUIRE_Q(args)

            for remoteQ in remoteQResponse:
                if not remoteQ[MQCA_Q_NAME].startswith(b'SYSTEM.') and not remoteQ[MQCA_Q_NAME].startswith(b'MQSERIES.TEMPLATE.'):
                    if not remoteQ[MQCA_Q_NAME].strip() == b'' and not remoteQ[MQCA_REMOTE_Q_NAME].strip() == b'' and not remoteQ[MQCA_REMOTE_Q_MGR_NAME].strip() == b'':
                        cluster = remoteQ[MQCA_CLUSTER_NAME].strip()
                        clusterNameList = remoteQ[MQCA_CLUSTER_NAMELIST].strip()
                        remoteQClusters = []
                        if cluster != b'':
                            remoteQClusters = [cluster]
                        elif clusterNameList != b'':
                            logger.info(f'Getting clusters for namelist: {clusterNameList} from remoteQueue {remoteQ[MQCA_Q_NAME]}')
                            args = {pymqi.CMQC.MQCA_NAMELIST_NAME : pymqi.ensure_bytes(clusterNameList)}
                            
                            try:
                                nameListResponse = pcf.MQCMD_INQUIRE_NAMELIST(args)
                                #remoteQClusters = [x.strip() for x in nameListResponse[0][MQCA_NAMES]]
                                for each in nameListResponse:
                                    if MQCA_NAMES in each:
                                        if isinstance(each[MQCA_NAMES], list):
                                            for x in each[MQCA_NAMES]:
                                                remoteQClusters.append(x.strip())
                                        else:
                                            remoteQClusters.append(each[MQCA_NAMES].strip())
                            except pymqi.MQMIError as e:
                                logger.error(f'Error getting remoteQ clusters in namelist {clusterNameList} for {self.queue_manager}. {e.errorAsString()}')
                                self.report_custom_info_event(f'Could not get clusters for namelist {str(clusterNameList, "utf-8", "ignore")} in {self.queue_manager}.', 'Error getting clusters from MQ', properties={'Queue manager': self.queue_manager, 'Error': e.errorAsString()})
                            
                            # In case there are duplicates
                            remoteQClusters = list( dict.fromkeys(remoteQClusters) )
                        cluster_data['remoteQueues'].append({'localQueue': remoteQ[MQCA_Q_NAME].strip(), 'remoteQueue': remoteQ[MQCA_REMOTE_Q_NAME].strip(), 'remoteQueueManager': remoteQ[MQCA_REMOTE_Q_MGR_NAME].strip(), 'clusterVisibility': remoteQClusters})
        except pymqi.MQMIError as e:
            logger.error(f'Error getting remote queues for {self.queue_manager}. {e.errorAsString()}')
            self.report_custom_info_event(f'Could not get remote queues in {self.queue_manager}.', 'Error getting remote queues from MQ', properties={'Queue manager': self.queue_manager, 'Error': e.errorAsString()})
        
        # Retrieve Cluster queue information
        logger.info('Getting cluster queue information')
        cluster_data['clusterQueues'] = []
        args = {pymqi.CMQC.MQCA_Q_NAME : b'*',
                pymqi.CMQC.MQIA_Q_TYPE : pymqi.CMQC.MQQT_CLUSTER}
                
        try:
            clusterQResponse = pcf.MQCMD_INQUIRE_Q(args)
            for clusterQ in clusterQResponse:
                cluster = clusterQ[MQCA_CLUSTER_NAME].strip()
                if not (clusterQ[MQCA_Q_NAME].strip() in [queue['aliasQueue'] for queue in cluster_data['aliasQueues']]) and not (clusterQ[MQCA_Q_NAME].strip() in [queue['localQueue'] for queue in cluster_data['remoteQueues']]) and not (clusterQ[MQCA_Q_NAME].strip() in [queue['localQueue'] for queue in cluster_data['clusterQueues']]):
                    if not clusterQ[MQCA_Q_NAME].strip() == '':
                        cluster_data['clusterQueues'].append({'localQueue': clusterQ[MQCA_Q_NAME].strip(), 'clusterVisibility': [cluster]})
        except pymqi.MQMIError as e:
            logger.error(f'Error getting cluster information for {self.queue_manager}. {e.errorAsString()}')
            self.report_custom_info_event(f'Could not get clusters queues for {self.queue_manager}.', 'Error getting clusters from MQ', properties={'Queue manager': self.queue_manager, 'Error': e.errorAsString()})

        jsonified = json.dumps( cluster_data, cls=EncodeText )
        
        return jsonified
        
    def send_topology(self,data,apiToken,endpoint):
        try:
            if not endpoint.endswith('/'):
                endpoint += '/'
            if not endpoint.startswith('http'):
                endpoint = 'https://'+endpoint
                
            url = f'{endpoint}api/config/v1/service/ibmMQTracing/queueManager/{self.queue_manager}'
            
            # Put the data
            response = requests.put(f'{url}', proxies=self.request_proxy_list, data=data, headers={'Content-Type': 'application/json', 'Authorization': f'Api-Token {apiToken}'}, verify=False, timeout=10)
            
            if response.status_code == 204 or response.status_code == 201:
                logger.info('Succeeded sending topology')
                self.last_topology_retrieve[self.queue_manager]['time'] = time.time()
                return True
            else:
                logger.error(f'Error sending topology to API {url}. Response code: {response.status_code}. {response.text}. Data: {data}')
                self.node.report_error_event(f'An error occurred sending queue manager {self.queue_manager} topology mapping to environment', 'Error sending MQ topology', properties={'Queue manager': self.queue_manager, 'Error code': str(response.status_code), 'Response': response.text})
                return False
        except Exception as e:
            logger.error(f'Failed to communicate with endpoint {url}. {e}')
            self.node.report_error_event(f'An error occurred sending queue manager {self.queue_manager} topology mapping to environment. Check plugin log for further error details.', 'Error sending MQ topology', properties={'Queue manager': self.queue_manager})
            return False